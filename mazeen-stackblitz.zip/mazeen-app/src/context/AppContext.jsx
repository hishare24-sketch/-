import { createContext, useContext, useState } from 'react';
import { projects, currentUser, notifications } from '../data/mockData';

const AppContext = createContext();

export function AppProvider({ children }) {
  const [activeProjectId, setActiveProjectId] = useState('p1');
  const [notifs, setNotifs] = useState(notifications);

  const activeProject = projects.find(p => p.id === activeProjectId);
  const unreadCount = notifs.filter(n => !n.read).length;

  const markAllRead = () => setNotifs(n => n.map(x => ({ ...x, read: true })));
  const markRead = (id) => setNotifs(n => n.map(x => x.id === id ? { ...x, read: true } : x));

  return (
    <AppContext.Provider value={{
      currentUser, projects, activeProject, activeProjectId,
      setActiveProjectId, notifs, unreadCount, markAllRead, markRead,
    }}>
      {children}
    </AppContext.Provider>
  );
}

export const useApp = () => useContext(AppContext);
