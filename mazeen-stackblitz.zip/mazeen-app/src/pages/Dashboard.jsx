import { useApp } from '../context/AppContext';
import { StatCard, Card, formatAmount, formatDate, StatusBadge, Button } from '../components/UI';
import { dashboardStats, transactions, trackings, requests } from '../data/mockData';

function SimpleBarChart({ data }) {
  const max = Math.max(...data.map(d => Math.max(d.income, d.expenses)));
  return (
    <div className="flex items-end gap-2 h-32 pt-2">
      {data.map((d, i) => (
        <div key={i} className="flex-1 flex flex-col items-center gap-1">
          <div className="w-full flex items-end gap-0.5" style={{ height: '100px' }}>
            <div
              className="flex-1 bg-blue-500 rounded-t-sm opacity-90"
              style={{ height: `${(d.income / max) * 100}%` }}
            />
            <div
              className="flex-1 bg-red-400 rounded-t-sm opacity-80"
              style={{ height: `${(d.expenses / max) * 100}%` }}
            />
          </div>
          <span className="text-xs text-gray-400 whitespace-nowrap">{d.month.slice(0, 3)}</span>
        </div>
      ))}
    </div>
  );
}

export default function Dashboard({ onNavigate }) {
  const { activeProject } = useApp();
  const recentTxns = transactions.filter(t => t.projectId === activeProject?.id).slice(0, 5);
  const urgentTrackings = trackings.filter(t => t.status === 'expiring' || t.status === 'expired').slice(0, 3);
  const pendingReqs = requests.filter(r => r.status === 'pending').slice(0, 3);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">لوحة التحكم</h1>
          <p className="text-sm text-gray-500 mt-1">{activeProject?.name} — يونيو 2025</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm">📊 تقرير شهري</Button>
          <Button size="sm" onClick={() => onNavigate('documents')}>+ رفع مستند</Button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
        <StatCard label="الرصيد الكلي"      value={formatAmount(dashboardStats.totalBalance)}   icon="💰" color="blue"   trend={8} />
        <StatCard label="إيرادات الشهر"      value={formatAmount(dashboardStats.monthlyIncome)}  icon="📈" color="green"  trend={12} />
        <StatCard label="مصروفات الشهر"      value={formatAmount(dashboardStats.monthlyExpenses)} icon="📉" color="red"   trend={-3} />
        <StatCard label="طلبات معلقة"        value={dashboardStats.pendingRequests}              icon="⏳" color="yellow" />
        <StatCard label="متابعات تنتهي قريباً" value={dashboardStats.expiringTrackings}          icon="⚠️" color="orange" />
        <StatCard label="المشاريع النشطة"    value={dashboardStats.activeProjects}               icon="⬡" color="purple" />
      </div>

      {/* Chart + Categories */}
      <div className="grid grid-cols-5 gap-4">
        <Card className="col-span-3 p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-gray-800">الإيرادات والمصروفات</h3>
            <div className="flex items-center gap-4 text-xs text-gray-500">
              <span className="flex items-center gap-1.5"><span className="w-3 h-3 rounded-sm bg-blue-500 inline-block" />إيرادات</span>
              <span className="flex items-center gap-1.5"><span className="w-3 h-3 rounded-sm bg-red-400 inline-block" />مصروفات</span>
            </div>
          </div>
          <SimpleBarChart data={dashboardStats.monthlyData} />
        </Card>

        <Card className="col-span-2 p-5">
          <h3 className="font-semibold text-gray-800 mb-4">توزيع المصروفات</h3>
          <div className="space-y-3">
            {dashboardStats.expensesByCategory.map((c, i) => (
              <div key={i}>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-gray-600">{c.category}</span>
                  <span className="font-medium">{c.percent}%</span>
                </div>
                <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full"
                    style={{
                      width: `${c.percent}%`,
                      backgroundColor: ['#3b82f6','#10b981','#f59e0b'][i],
                    }}
                  />
                </div>
                <p className="text-xs text-gray-400 mt-0.5">{formatAmount(c.amount)}</p>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Bottom row */}
      <div className="grid grid-cols-3 gap-4">

        {/* Recent transactions */}
        <Card className="col-span-1 p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-gray-800">آخر العمليات</h3>
            <button onClick={() => onNavigate('finance')} className="text-xs text-blue-600 hover:underline">عرض الكل</button>
          </div>
          <div className="space-y-3">
            {recentTxns.map(t => (
              <div key={t.id} className="flex items-center gap-3">
                <div className={`w-8 h-8 rounded-lg flex items-center justify-center text-sm flex-shrink-0 ${t.type === 'income' ? 'bg-green-50 text-green-600' : 'bg-red-50 text-red-500'}`}>
                  {t.type === 'income' ? '↑' : '↓'}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-gray-700 truncate">{t.description}</p>
                  <p className="text-xs text-gray-400">{formatDate(t.date)}</p>
                </div>
                <p className={`text-sm font-semibold flex-shrink-0 ${t.type === 'income' ? 'text-green-600' : 'text-red-500'}`}>
                  {t.type === 'income' ? '+' : '-'}{t.amount.toLocaleString()}
                </p>
              </div>
            ))}
          </div>
        </Card>

        {/* Expiring trackings */}
        <Card className="col-span-1 p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-gray-800">تنبيهات المتابعات</h3>
            <button onClick={() => onNavigate('trackings')} className="text-xs text-blue-600 hover:underline">عرض الكل</button>
          </div>
          {urgentTrackings.length === 0 ? (
            <p className="text-sm text-gray-400 text-center py-6">لا توجد تنبيهات</p>
          ) : (
            <div className="space-y-3">
              {urgentTrackings.map(t => (
                <div key={t.id} className={`flex items-center gap-3 p-3 rounded-xl ${t.status === 'expired' ? 'bg-red-50' : 'bg-yellow-50'}`}>
                  <span className="text-xl">{t.icon}</span>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-800 truncate">{t.name}</p>
                    <p className={`text-xs ${t.status === 'expired' ? 'text-red-600' : 'text-yellow-700'}`}>
                      {t.status === 'expired' ? 'انتهى الضمان' : `يوشك على الانتهاء — ${t.daysLeft} يوم`}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </Card>

        {/* Pending requests */}
        <Card className="col-span-1 p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-gray-800">طلبات تنتظر موافقتك</h3>
            <button onClick={() => onNavigate('requests')} className="text-xs text-blue-600 hover:underline">عرض الكل</button>
          </div>
          <div className="space-y-3">
            {pendingReqs.map(r => (
              <div key={r.id} className="p-3 bg-yellow-50 rounded-xl">
                <div className="flex items-start justify-between gap-2">
                  <p className="text-sm font-medium text-gray-800 leading-snug">{r.title}</p>
                  <span className="text-sm font-bold text-gray-700 flex-shrink-0">{r.amount.toLocaleString()}</span>
                </div>
                <p className="text-xs text-gray-500 mt-1">من: {r.requestedBy}</p>
                <div className="flex gap-2 mt-2">
                  <button className="flex-1 bg-green-600 text-white text-xs py-1.5 rounded-lg font-medium hover:bg-green-700">موافقة</button>
                  <button className="flex-1 bg-red-50 text-red-600 text-xs py-1.5 rounded-lg font-medium hover:bg-red-100">رفض</button>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}
