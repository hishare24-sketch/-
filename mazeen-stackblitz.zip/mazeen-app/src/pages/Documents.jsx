import { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Card, Button, Badge, PageHeader, StatusBadge, formatDate, formatAmount } from '../components/UI';
import { documents } from '../data/mockData';

export default function Documents({ onNavigate }) {
  const { activeProject } = useApp();
  const [selected, setSelected] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [aiProcessing, setAiProcessing] = useState(false);
  const [filter, setFilter] = useState('الكل');

  const projectDocs = documents.filter(d => d.projectId === activeProject?.id);
  const types = ['الكل', 'فاتورة', 'عقد', 'وثيقة رسمية'];
  const filtered = projectDocs.filter(d => filter === 'الكل' || d.type === filter);

  const simulateUpload = () => {
    setUploading(true);
    setTimeout(() => { setUploading(false); setAiProcessing(true); }, 1500);
    setTimeout(() => { setAiProcessing(false); setSelected(documents[0]); }, 3500);
  };

  const typeIcon = (type) => ({ 'فاتورة': '🧾', 'عقد': '📝', 'وثيقة رسمية': '📋', 'صورة': '🖼️' })[type] || '📄';

  return (
    <div className="space-y-5">
      <PageHeader
        title="المستندات"
        subtitle={`${filtered.length} مستند — ${activeProject?.name}`}
        actions={
          <Button size="sm" onClick={simulateUpload} disabled={uploading || aiProcessing}>
            {uploading ? '⏳ جارٍ الرفع...' : aiProcessing ? '🤖 يحلل الذكاء الاصطناعي...' : '+ رفع مستند'}
          </Button>
        }
      />

      {/* AI Processing banner */}
      {aiProcessing && (
        <div className="bg-blue-50 border border-blue-200 rounded-2xl p-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-blue-100 flex items-center justify-center text-xl animate-pulse">🤖</div>
          <div>
            <p className="font-medium text-blue-800">الذكاء الاصطناعي يقرأ المستند...</p>
            <p className="text-sm text-blue-600">جارٍ استخراج البيانات والتفاصيل تلقائياً</p>
          </div>
          <div className="mr-auto flex gap-1">
            {[0,1,2].map(i => (
              <div key={i} className="w-2 h-2 bg-blue-500 rounded-full animate-bounce" style={{ animationDelay: `${i * 0.15}s` }} />
            ))}
          </div>
        </div>
      )}

      {/* Upload drop zone */}
      <div
        onClick={simulateUpload}
        className="border-2 border-dashed border-gray-200 rounded-2xl p-8 text-center cursor-pointer hover:border-blue-400 hover:bg-blue-50/30 transition-all"
      >
        <div className="text-4xl mb-2">📂</div>
        <p className="font-medium text-gray-700">اسحب الملف هنا أو انقر للرفع</p>
        <p className="text-sm text-gray-400 mt-1">PDF، صور (JPG، PNG) — الحد الأقصى 20 ميغابايت</p>
        <p className="text-xs text-blue-500 mt-2">🤖 سيقوم الذكاء الاصطناعي بقراءة المستند وتحليله تلقائياً</p>
      </div>

      <div className="flex gap-4">
        {/* Document list */}
        <Card className="flex-1 p-5">
          {/* Filter */}
          <div className="flex gap-2 mb-4">
            {types.map(t => (
              <button
                key={t}
                onClick={() => setFilter(t)}
                className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${filter === t ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}
              >
                {typeIcon(t !== 'الكل' ? t : '')} {t}
              </button>
            ))}
          </div>

          <div className="space-y-2">
            {filtered.map(doc => (
              <div
                key={doc.id}
                onClick={() => setSelected(doc)}
                className={`flex items-center gap-4 p-4 rounded-xl cursor-pointer transition-all border ${selected?.id === doc.id ? 'border-blue-200 bg-blue-50' : 'border-transparent hover:bg-gray-50'}`}
              >
                <div className="w-10 h-12 bg-gray-100 rounded-lg flex items-center justify-center text-xl flex-shrink-0">
                  {typeIcon(doc.fileType === 'صورة' ? 'صورة' : doc.type)}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-gray-800 truncate">{doc.name}</p>
                  <div className="flex items-center gap-3 mt-1">
                    <span className="text-xs text-gray-400">{formatDate(doc.uploadedAt)}</span>
                    <span className="text-xs text-gray-400">{doc.size}</span>
                    <Badge label={doc.type} color="gray" />
                  </div>
                </div>
                <div className="flex flex-col items-end gap-1 flex-shrink-0">
                  <StatusBadge status={doc.status} />
                  {doc.aiExtracted && (
                    <span className="text-xs text-blue-500 bg-blue-50 px-2 py-0.5 rounded-full">🤖 AI</span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </Card>

        {/* AI Result Panel */}
        {selected && (
          <Card className="w-80 p-5 flex-shrink-0">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-gray-800">نتائج الذكاء الاصطناعي</h3>
              <button onClick={() => setSelected(null)} className="text-gray-400 hover:text-gray-600">✕</button>
            </div>

            <div className="bg-blue-50 rounded-xl p-3 mb-4 flex items-center gap-2">
              <span className="text-xl">🤖</span>
              <div>
                <p className="text-xs font-semibold text-blue-700">تم استخراج البيانات تلقائياً</p>
                <p className="text-xs text-blue-500">بدقة عالية — يُرجى المراجعة</p>
              </div>
            </div>

            <p className="font-semibold text-gray-800 mb-3 truncate">{selected.name}</p>

            <div className="space-y-3 text-sm mb-4">
              {selected.aiData?.vendor && (
                <div className="flex justify-between">
                  <span className="text-gray-500">المورد / الطرف</span>
                  <span className="font-medium text-gray-800 text-left">{selected.aiData.vendor}</span>
                </div>
              )}
              {selected.aiData?.amount && (
                <div className="flex justify-between">
                  <span className="text-gray-500">المبلغ</span>
                  <span className="font-bold text-blue-700">{formatAmount(selected.aiData.amount)}</span>
                </div>
              )}
              {selected.aiData?.date && (
                <div className="flex justify-between">
                  <span className="text-gray-500">التاريخ</span>
                  <span className="font-medium">{formatDate(selected.aiData.date)}</span>
                </div>
              )}
              {selected.aiData?.contractEnd && (
                <div className="flex justify-between">
                  <span className="text-gray-500">انتهاء العقد</span>
                  <span className="font-medium text-orange-600">{formatDate(selected.aiData.contractEnd)}</span>
                </div>
              )}
              {selected.aiData?.warranty && (
                <div className="bg-yellow-50 rounded-xl p-3">
                  <p className="text-xs font-semibold text-yellow-700 mb-1">⚠️ تم اكتشاف ضمان</p>
                  <p className="text-xs text-yellow-600">مدة الضمان: {selected.aiData.warranty.months} شهراً</p>
                  <p className="text-xs text-yellow-600">ينتهي في: {formatDate(selected.aiData.warranty.expiresAt)}</p>
                </div>
              )}
              {selected.aiData?.items && (
                <div>
                  <p className="text-gray-500 mb-1">البنود</p>
                  {selected.aiData.items.map((item, i) => (
                    <p key={i} className="text-xs text-gray-600 bg-gray-50 px-2 py-1 rounded-lg mb-1">• {item}</p>
                  ))}
                </div>
              )}
            </div>

            <div className="border-t border-gray-100 pt-4 space-y-2">
              <p className="text-xs text-gray-500 mb-2 font-medium">إجراءات مقترحة:</p>
              <Button size="sm" className="w-full justify-center">✅ إنشاء عملية مالية</Button>
              {selected.aiData?.warranty && (
                <Button variant="outline" size="sm" className="w-full justify-center">🔔 إضافة متابعة ضمان</Button>
              )}
              {selected.aiData?.contractEnd && (
                <Button variant="outline" size="sm" className="w-full justify-center">📅 إضافة تنبيه العقد</Button>
              )}
              <Button variant="ghost" size="sm" className="w-full justify-center text-gray-400">تجاهل</Button>
            </div>
          </Card>
        )}
      </div>
    </div>
  );
}
