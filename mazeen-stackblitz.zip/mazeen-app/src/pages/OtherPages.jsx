// ═══════════════════════════════
//  صفحة الطلبات والموافقات
// ═══════════════════════════════
import { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Card, Button, StatusBadge, PageHeader, Badge, Avatar, formatAmount, formatDate } from '../components/UI';
import { requests } from '../data/mockData';

const tabs = ['الكل', 'قيد المراجعة', 'معتمد', 'مكتمل'];

export function Requests() {
  const { activeProject } = useApp();
  const [tab, setTab] = useState('الكل');
  const [selected, setSelected] = useState(null);
  const [localReqs, setLocalReqs] = useState(requests);

  const projectReqs = localReqs.filter(r => r.projectId === activeProject?.id);
  const filtered = projectReqs.filter(r => {
    if (tab === 'الكل') return true;
    if (tab === 'قيد المراجعة') return r.status === 'pending';
    if (tab === 'معتمد') return r.status === 'approved';
    if (tab === 'مكتمل') return r.status === 'completed';
    return true;
  });

  const approve = (id) => setLocalReqs(r => r.map(x => x.id === id ? { ...x, status: 'approved' } : x));
  const reject  = (id) => setLocalReqs(r => r.map(x => x.id === id ? { ...x, status: 'rejected' } : x));

  const typeIcon = { 'مصروف': '💸', 'عهدة': '🧾', 'تحويل': '🔄', 'تسوية': '⚖️' };
  const priorityBadge = { 'high': { label: 'عاجل', color: 'red' }, 'normal': { label: 'عادي', color: 'gray' } };

  return (
    <div className="space-y-5">
      <PageHeader
        title="الطلبات والموافقات"
        subtitle={`${projectReqs.filter(r => r.status === 'pending').length} طلب معلق`}
        actions={<Button size="sm">+ طلب جديد</Button>}
      />

      {/* Tabs */}
      <div className="flex gap-1 bg-gray-100 p-1 rounded-xl w-fit">
        {tabs.map(t => (
          <button key={t} onClick={() => setTab(t)}
            className={`px-4 py-1.5 rounded-lg text-sm font-medium transition-colors ${tab === t ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
          >{t}</button>
        ))}
      </div>

      <div className="flex gap-4">
        <Card className="flex-1 p-5">
          <div className="space-y-3">
            {filtered.map(req => (
              <div
                key={req.id}
                onClick={() => setSelected(req)}
                className={`flex items-center gap-4 p-4 rounded-xl cursor-pointer border-2 transition-all ${selected?.id === req.id ? 'border-blue-200 bg-blue-50' : 'border-transparent hover:bg-gray-50'}`}
              >
                <div className="w-10 h-10 bg-gray-100 rounded-xl flex items-center justify-center text-xl flex-shrink-0">
                  {typeIcon[req.type] || '📋'}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-0.5">
                    <p className="font-medium text-gray-800 truncate">{req.title}</p>
                    <Badge label={priorityBadge[req.priority]?.label} color={priorityBadge[req.priority]?.color} />
                  </div>
                  <p className="text-xs text-gray-400">من: {req.requestedBy} · {formatDate(req.date)}</p>
                </div>
                <div className="flex flex-col items-end gap-2 flex-shrink-0">
                  <p className="font-bold text-gray-800">{formatAmount(req.amount)}</p>
                  <StatusBadge status={req.status} />
                </div>
              </div>
            ))}
          </div>
        </Card>

        {selected && (
          <Card className="w-72 p-5 flex-shrink-0">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-gray-800">تفاصيل الطلب</h3>
              <button onClick={() => setSelected(null)} className="text-gray-400 hover:text-gray-600">✕</button>
            </div>

            <div className="text-3xl text-center mb-2">{typeIcon[selected.type]}</div>
            <p className="font-bold text-gray-800 text-center mb-1">{selected.title}</p>
            <p className="text-2xl font-black text-blue-700 text-center mb-4">{formatAmount(selected.amount)}</p>

            <div className="bg-gray-50 rounded-xl p-3 mb-4 text-sm text-gray-600">{selected.description}</div>

            <div className="space-y-2 text-sm mb-4">
              {[
                ['مقدّم من', selected.requestedBy],
                ['نوع الطلب', selected.type],
                ['التاريخ', formatDate(selected.date)],
                ['الحالة', <StatusBadge status={selected.status} />],
                ['المرفقات', selected.attachments > 0 ? `${selected.attachments} ملف` : 'لا يوجد'],
              ].map(([k, v]) => (
                <div key={k} className="flex justify-between items-center">
                  <span className="text-gray-500">{k}</span>
                  <span className="font-medium">{v}</span>
                </div>
              ))}
            </div>

            {selected.status === 'pending' && (
              <div className="flex gap-2">
                <Button variant="success" size="sm" className="flex-1 justify-center" onClick={() => approve(selected.id)}>✅ موافقة</Button>
                <Button variant="danger" size="sm" className="flex-1 justify-center" onClick={() => reject(selected.id)}>❌ رفض</Button>
              </div>
            )}
            {selected.status !== 'pending' && (
              <div className="text-center py-2 text-sm text-gray-400">
                {selected.status === 'approved' ? '✅ تمت الموافقة' : selected.status === 'completed' ? '✅ مكتمل' : '❌ مرفوض'}
              </div>
            )}
          </Card>
        )}
      </div>
    </div>
  );
}

// ═══════════════════════════════
//  صفحة الإشعارات
// ═══════════════════════════════
export function Notifications() {
  const { notifs, markAllRead, markRead } = useApp();
  const typeStyle = {
    warning: { bg: 'bg-yellow-50 border-yellow-100', dot: 'bg-yellow-400' },
    request: { bg: 'bg-blue-50 border-blue-100',    dot: 'bg-blue-500' },
    ai:      { bg: 'bg-purple-50 border-purple-100', dot: 'bg-purple-500' },
    success: { bg: 'bg-green-50 border-green-100',  dot: 'bg-green-500' },
    info:    { bg: 'bg-gray-50 border-gray-100',    dot: 'bg-gray-400' },
  };

  return (
    <div className="space-y-5">
      <PageHeader
        title="الإشعارات والتنبيهات"
        subtitle={`${notifs.filter(n => !n.read).length} إشعار غير مقروء`}
        actions={<Button variant="outline" size="sm" onClick={markAllRead}>تحديد الكل كمقروء</Button>}
      />
      <Card className="p-5">
        <div className="space-y-3">
          {notifs.map(n => {
            const s = typeStyle[n.type] || typeStyle.info;
            return (
              <div
                key={n.id}
                onClick={() => markRead(n.id)}
                className={`flex items-start gap-4 p-4 rounded-xl border cursor-pointer transition-all ${s.bg} ${n.read ? 'opacity-60' : ''}`}
              >
                <div className="relative">
                  <span className="text-2xl">{n.icon}</span>
                  {!n.read && <span className={`absolute -top-1 -left-1 w-3 h-3 rounded-full border-2 border-white ${s.dot}`} />}
                </div>
                <div className="flex-1">
                  <p className={`text-sm font-semibold ${n.read ? 'text-gray-600' : 'text-gray-900'}`}>{n.title}</p>
                  <p className="text-xs text-gray-500 mt-0.5">{n.message}</p>
                  <p className="text-xs text-gray-400 mt-1">{formatDate(n.date)}</p>
                </div>
                {!n.read && <span className="w-2 h-2 rounded-full bg-blue-500 flex-shrink-0 mt-2" />}
              </div>
            );
          })}
        </div>
      </Card>
    </div>
  );
}

// ═══════════════════════════════
//  صفحة المشاريع
// ═══════════════════════════════
export function Projects() {
  const { projects, setActiveProjectId, activeProject } = useApp();
  return (
    <div className="space-y-5">
      <PageHeader
        title="المشاريع"
        subtitle="إدارة جميع مشاريعك"
        actions={<Button size="sm">+ مشروع جديد</Button>}
      />
      <div className="grid grid-cols-3 gap-4">
        {projects.map(p => (
          <Card key={p.id} className="p-6" onClick={() => setActiveProjectId(p.id)}>
            <div className="flex items-start justify-between mb-4">
              <div className="w-12 h-12 rounded-2xl flex items-center justify-center text-2xl" style={{ backgroundColor: p.color + '20' }}>
                {p.icon}
              </div>
              {activeProject?.id === p.id && (
                <span className="text-xs bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full font-medium">محدد</span>
              )}
            </div>
            <h3 className="font-bold text-gray-900 mb-1">{p.name}</h3>
            <p className="text-xs text-gray-400 mb-4">{p.description}</p>
            <div className="border-t border-gray-100 pt-4 flex justify-between text-sm">
              <div>
                <p className="text-xs text-gray-400">الرصيد</p>
                <p className="font-bold text-gray-800">{p.balance.toLocaleString()} ر.س</p>
              </div>
              <div className="text-left">
                <p className="text-xs text-gray-400">الأعضاء</p>
                <p className="font-bold text-gray-800">{p.membersCount}</p>
              </div>
            </div>
            <button className="w-full mt-4 bg-gray-50 hover:bg-gray-100 text-gray-600 text-sm py-2 rounded-xl transition-colors" onClick={() => setActiveProjectId(p.id)}>
              تفعيل المشروع →
            </button>
          </Card>
        ))}
        {/* Add project card */}
        <div className="border-2 border-dashed border-gray-200 rounded-2xl p-6 flex flex-col items-center justify-center cursor-pointer hover:border-blue-300 hover:bg-blue-50/20 transition-all text-center min-h-48">
          <div className="w-12 h-12 rounded-2xl bg-gray-100 flex items-center justify-center text-2xl mb-3">+</div>
          <p className="font-medium text-gray-600">إضافة مشروع جديد</p>
          <p className="text-xs text-gray-400 mt-1">شركة، منزل، مطعم...</p>
        </div>
      </div>
    </div>
  );
}

// ═══════════════════════════════
//  صفحة الإعدادات
// ═══════════════════════════════
export function Settings() {
  const { currentUser } = useApp();
  const sections = [
    {
      title: 'الملف الشخصي',
      items: [
        { label: 'الاسم', value: currentUser.name, type: 'text' },
        { label: 'البريد الإلكتروني', value: currentUser.email, type: 'email' },
        { label: 'رقم الجوال', value: currentUser.phone, type: 'text' },
      ],
    },
    {
      title: 'الإشعارات',
      items: [
        { label: 'إشعارات البريد الإلكتروني', value: true, type: 'toggle' },
        { label: 'إشعارات الواتساب', value: false, type: 'toggle' },
        { label: 'إشعارات التطبيق', value: true, type: 'toggle' },
        { label: 'التنبيه قبل انتهاء الضمان', value: '30 يوم', type: 'text' },
      ],
    },
    {
      title: 'الأمان',
      items: [
        { label: 'تغيير كلمة المرور', value: '••••••••', type: 'password' },
        { label: 'المصادقة الثنائية', value: false, type: 'toggle' },
      ],
    },
  ];

  return (
    <div className="space-y-5">
      <PageHeader title="الإعدادات" subtitle="إدارة حسابك وتفضيلاتك" />
      <div className="max-w-2xl space-y-4">
        {/* Avatar */}
        <Card className="p-6">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-blue-600 flex items-center justify-center text-white text-3xl font-bold">
              {currentUser.avatar}
            </div>
            <div>
              <h3 className="font-bold text-gray-900 text-lg">{currentUser.name}</h3>
              <p className="text-sm text-gray-500">{currentUser.email}</p>
              <p className="text-xs text-blue-600 mt-1">{currentUser.role}</p>
            </div>
            <Button variant="outline" size="sm" className="mr-auto">تغيير الصورة</Button>
          </div>
        </Card>

        {sections.map(section => (
          <Card key={section.title} className="p-6">
            <h3 className="font-semibold text-gray-800 mb-4 pb-3 border-b border-gray-100">{section.title}</h3>
            <div className="space-y-4">
              {section.items.map(item => (
                <div key={item.label} className="flex items-center justify-between">
                  <label className="text-sm text-gray-700">{item.label}</label>
                  {item.type === 'toggle' ? (
                    <div className={`w-11 h-6 rounded-full transition-colors cursor-pointer ${item.value ? 'bg-blue-600' : 'bg-gray-200'} relative`}>
                      <div className={`w-5 h-5 bg-white rounded-full absolute top-0.5 transition-all shadow-sm ${item.value ? 'left-5' : 'left-0.5'}`} />
                    </div>
                  ) : (
                    <input
                      type={item.type}
                      defaultValue={item.value}
                      className="border border-gray-200 rounded-lg px-3 py-1.5 text-sm text-gray-700 w-52 text-right focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  )}
                </div>
              ))}
            </div>
          </Card>
        ))}

        <Button variant="primary" size="md">حفظ التغييرات</Button>
      </div>
    </div>
  );
}
