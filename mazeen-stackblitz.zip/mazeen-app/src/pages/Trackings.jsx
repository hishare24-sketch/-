import { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Card, Button, StatusBadge, PageHeader, Badge, formatDate } from '../components/UI';
import { trackings } from '../data/mockData';

const typeColors = {
  'ضمان': 'blue', 'عقد': 'purple', 'وثيقة رسمية': 'green',
  'اشتراك': 'orange', 'أصل': 'gray',
};

export default function Trackings() {
  const { activeProject } = useApp();
  const [filter, setFilter] = useState('الكل');
  const [selected, setSelected] = useState(null);

  const projectTrackings = trackings.filter(t => t.projectId === activeProject?.id);
  const types = ['الكل', 'ضمان', 'عقد', 'وثيقة رسمية', 'اشتراك', 'أصل'];
  const filtered = projectTrackings.filter(t => filter === 'الكل' || t.type === filter);

  const getDaysColor = (days, status) => {
    if (status === 'expired') return 'text-red-600 bg-red-50';
    if (days <= 14) return 'text-yellow-700 bg-yellow-50';
    if (days <= 60) return 'text-orange-600 bg-orange-50';
    return 'text-green-700 bg-green-50';
  };

  const getDaysLabel = (days, status) => {
    if (status === 'expired') return `منتهي منذ ${Math.abs(days)} يوم`;
    return `${days} يوم متبقية`;
  };

  return (
    <div className="space-y-5">
      <PageHeader
        title="المتابعات والضمانات"
        subtitle={`${filtered.length} عنصر نشط`}
        actions={<Button size="sm">+ إضافة متابعة</Button>}
      />

      {/* Alert summary */}
      <div className="grid grid-cols-4 gap-3">
        {[
          { label: 'نشط', count: projectTrackings.filter(t => t.status === 'active').length, color: 'green', icon: '✅' },
          { label: 'يوشك على الانتهاء', count: projectTrackings.filter(t => t.status === 'expiring').length, color: 'yellow', icon: '⚠️' },
          { label: 'منتهي', count: projectTrackings.filter(t => t.status === 'expired').length, color: 'red', icon: '❌' },
          { label: 'إجمالي العناصر', count: projectTrackings.length, color: 'blue', icon: '📋' },
        ].map((s, i) => (
          <div key={i} className={`rounded-2xl p-4 ${s.color === 'green' ? 'bg-green-50' : s.color === 'yellow' ? 'bg-yellow-50' : s.color === 'red' ? 'bg-red-50' : 'bg-blue-50'}`}>
            <p className="text-2xl mb-1">{s.icon}</p>
            <p className={`text-2xl font-bold ${s.color === 'green' ? 'text-green-700' : s.color === 'yellow' ? 'text-yellow-700' : s.color === 'red' ? 'text-red-700' : 'text-blue-700'}`}>{s.count}</p>
            <p className="text-xs text-gray-500">{s.label}</p>
          </div>
        ))}
      </div>

      {/* Filter */}
      <div className="flex gap-2 flex-wrap">
        {types.map(t => (
          <button
            key={t}
            onClick={() => setFilter(t)}
            className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${filter === t ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}
          >
            {t}
          </button>
        ))}
      </div>

      <div className="flex gap-4">
        {/* Cards list */}
        <div className="flex-1 grid grid-cols-2 gap-3 content-start">
          {filtered.map(item => (
            <Card
              key={item.id}
              onClick={() => setSelected(item)}
              className={`p-4 border-2 transition-all ${selected?.id === item.id ? 'border-blue-300' : 'border-transparent'}`}
            >
              <div className="flex items-start justify-between mb-3">
                <span className="text-2xl">{item.icon}</span>
                <StatusBadge status={item.status} />
              </div>
              <p className="font-semibold text-gray-800 mb-1 leading-snug">{item.name}</p>
              <p className="text-xs text-gray-400 mb-3">{item.vendor}</p>

              {/* Days progress */}
              <div className={`text-xs font-semibold px-2 py-1 rounded-lg w-fit mb-3 ${getDaysColor(item.daysLeft, item.status)}`}>
                {getDaysLabel(item.daysLeft, item.status)}
              </div>

              <div className="flex items-center justify-between text-xs text-gray-400">
                <span>ينتهي: {formatDate(item.endDate)}</span>
                <Badge label={item.type} color={typeColors[item.type] || 'gray'} />
              </div>
            </Card>
          ))}
        </div>

        {/* Detail panel */}
        {selected && (
          <Card className="w-72 p-5 flex-shrink-0">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-gray-800">التفاصيل</h3>
              <button onClick={() => setSelected(null)} className="text-gray-400 hover:text-gray-600">✕</button>
            </div>

            <div className="text-4xl text-center mb-4">{selected.icon}</div>
            <p className="font-bold text-gray-800 text-center mb-1">{selected.name}</p>
            <p className="text-sm text-gray-400 text-center mb-4">{selected.vendor}</p>

            <div className={`text-center text-sm font-semibold py-2 rounded-xl mb-4 ${getDaysColor(selected.daysLeft, selected.status)}`}>
              {getDaysLabel(selected.daysLeft, selected.status)}
            </div>

            <div className="space-y-3 text-sm border-t border-gray-100 pt-4">
              {[
                ['النوع', <Badge label={selected.type} color={typeColors[selected.type] || 'gray'} />],
                ['الحالة', <StatusBadge status={selected.status} />],
                ['تاريخ البداية', formatDate(selected.startDate)],
                ['تاريخ الانتهاء', formatDate(selected.endDate)],
                ['التنبيه قبل', `${selected.alertDays} يوم`],
              ].map(([k, v]) => (
                <div key={k} className="flex justify-between items-center">
                  <span className="text-gray-500">{k}</span>
                  <span className="font-medium">{v}</span>
                </div>
              ))}
            </div>

            {selected.notes && (
              <div className="mt-4 bg-gray-50 rounded-xl p-3 text-xs text-gray-600">
                📝 {selected.notes}
              </div>
            )}

            <div className="space-y-2 mt-4">
              <Button size="sm" className="w-full justify-center">🔔 تعديل التنبيه</Button>
              {selected.status === 'expiring' && (
                <Button variant="success" size="sm" className="w-full justify-center">♻️ تجديد</Button>
              )}
              <Button variant="outline" size="sm" className="w-full justify-center">📄 عرض المستند</Button>
            </div>
          </Card>
        )}
      </div>
    </div>
  );
}
