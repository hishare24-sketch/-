import { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Card, Button, StatusBadge, PageHeader, formatAmount, formatDate, Badge } from '../components/UI';
import { transactions } from '../data/mockData';

const tabs = ['الكل', 'إيرادات', 'مصروفات', 'تحويلات'];
const categories = ['الكل', 'مبيعات', 'رواتب', 'إيجار', 'صيانة', 'فواتير'];

export default function Finance() {
  const { activeProject } = useApp();
  const [activeTab, setActiveTab] = useState('الكل');
  const [activeCategory, setActiveCategory] = useState('الكل');
  const [selected, setSelected] = useState(null);

  const projectTxns = transactions.filter(t => t.projectId === activeProject?.id);
  const filtered = projectTxns.filter(t => {
    const typeMatch = activeTab === 'الكل' || (activeTab === 'إيرادات' && t.type === 'income') || (activeTab === 'مصروفات' && t.type === 'expense');
    const catMatch = activeCategory === 'الكل' || t.category === activeCategory;
    return typeMatch && catMatch;
  });

  const totalIncome = projectTxns.filter(t => t.type === 'income').reduce((s, t) => s + t.amount, 0);
  const totalExpense = projectTxns.filter(t => t.type === 'expense').reduce((s, t) => s + t.amount, 0);
  const net = totalIncome - totalExpense;

  return (
    <div className="space-y-5">
      <PageHeader
        title="الإدارة المالية"
        subtitle={activeProject?.name}
        actions={
          <>
            <Button variant="outline" size="sm">📥 تصدير</Button>
            <Button size="sm">+ عملية جديدة</Button>
          </>
        }
      />

      {/* Summary */}
      <div className="grid grid-cols-3 gap-4">
        {[
          { label: 'إجمالي الإيرادات', value: totalIncome, color: 'text-green-600', bg: 'bg-green-50', icon: '📈' },
          { label: 'إجمالي المصروفات', value: totalExpense, color: 'text-red-600', bg: 'bg-red-50', icon: '📉' },
          { label: 'صافي الربح', value: net, color: net >= 0 ? 'text-blue-600' : 'text-red-600', bg: 'bg-blue-50', icon: '💰' },
        ].map((s, i) => (
          <div key={i} className={`${s.bg} rounded-2xl p-5 flex items-center gap-4`}>
            <span className="text-3xl">{s.icon}</span>
            <div>
              <p className="text-xs text-gray-500">{s.label}</p>
              <p className={`text-xl font-bold ${s.color}`}>{formatAmount(s.value)}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="flex gap-4">
        {/* List */}
        <Card className="flex-1 p-5">
          {/* Tabs */}
          <div className="flex gap-1 mb-4 bg-gray-100 p-1 rounded-xl w-fit">
            {tabs.map(tab => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`px-4 py-1.5 rounded-lg text-sm font-medium transition-colors ${activeTab === tab ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
              >
                {tab}
              </button>
            ))}
          </div>

          {/* Category filter */}
          <div className="flex flex-wrap gap-2 mb-4">
            {categories.map(cat => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-3 py-1 rounded-full text-xs font-medium border transition-colors ${activeCategory === cat ? 'bg-blue-600 text-white border-blue-600' : 'border-gray-200 text-gray-600 hover:border-blue-300'}`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Table */}
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-gray-100">
                <th className="text-right py-2 font-medium text-gray-500">الوصف</th>
                <th className="text-right py-2 font-medium text-gray-500">التصنيف</th>
                <th className="text-right py-2 font-medium text-gray-500">التاريخ</th>
                <th className="text-right py-2 font-medium text-gray-500">المبلغ</th>
                <th className="text-right py-2 font-medium text-gray-500">مستند</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(t => (
                <tr
                  key={t.id}
                  onClick={() => setSelected(t)}
                  className={`border-b border-gray-50 hover:bg-gray-50 cursor-pointer transition-colors ${selected?.id === t.id ? 'bg-blue-50' : ''}`}
                >
                  <td className="py-3">
                    <div className="flex items-center gap-2">
                      <span className={`w-7 h-7 rounded-lg flex items-center justify-center text-xs ${t.type === 'income' ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-500'}`}>
                        {t.type === 'income' ? '↑' : '↓'}
                      </span>
                      <span className="text-gray-700">{t.description}</span>
                    </div>
                  </td>
                  <td className="py-3">
                    <Badge label={t.category} color="gray" />
                  </td>
                  <td className="py-3 text-gray-500">{formatDate(t.date)}</td>
                  <td className={`py-3 font-semibold ${t.type === 'income' ? 'text-green-600' : 'text-red-500'}`}>
                    {t.type === 'income' ? '+' : '-'}{t.amount.toLocaleString()} ر.س
                  </td>
                  <td className="py-3">
                    {t.documentId
                      ? <span className="text-blue-500 text-xs bg-blue-50 px-2 py-0.5 rounded-full">📄 مرفق</span>
                      : <span className="text-gray-300 text-xs">—</span>
                    }
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>

        {/* Detail panel */}
        {selected && (
          <Card className="w-64 p-5 flex-shrink-0">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-gray-800">تفاصيل العملية</h3>
              <button onClick={() => setSelected(null)} className="text-gray-400 hover:text-gray-600">✕</button>
            </div>
            <div className={`w-12 h-12 rounded-xl flex items-center justify-center text-xl mb-4 ${selected.type === 'income' ? 'bg-green-100' : 'bg-red-100'}`}>
              {selected.type === 'income' ? '📈' : '📉'}
            </div>
            <p className="text-lg font-bold text-gray-900 mb-1">{formatAmount(selected.amount)}</p>
            <p className="text-sm text-gray-500 mb-4">{selected.description}</p>
            <div className="space-y-3 text-sm">
              {[
                ['التصنيف', selected.category],
                ['التاريخ', formatDate(selected.date)],
                ['القناة', selected.channel],
                ['الحالة', <StatusBadge status={selected.status} />],
              ].map(([k, v]) => (
                <div key={k} className="flex justify-between items-center">
                  <span className="text-gray-500">{k}</span>
                  <span className="font-medium text-gray-800">{v}</span>
                </div>
              ))}
            </div>
            {selected.documentId && (
              <button className="w-full mt-4 bg-blue-50 text-blue-600 text-sm py-2 rounded-xl font-medium hover:bg-blue-100">
                📄 عرض المستند
              </button>
            )}
          </Card>
        )}
      </div>
    </div>
  );
}
