import { useState } from 'react';
import { AppProvider } from './context/AppContext';
import Sidebar from './components/Sidebar';
import Dashboard from './pages/Dashboard';
import Finance from './pages/Finance';
import Documents from './pages/Documents';
import Trackings from './pages/Trackings';
import { Requests, Notifications, Projects, Settings } from './pages/OtherPages';

function AppShell() {
  const [page, setPage] = useState('dashboard');

  const pages = {
    dashboard:     <Dashboard onNavigate={setPage} />,
    projects:      <Projects />,
    finance:       <Finance />,
    documents:     <Documents onNavigate={setPage} />,
    trackings:     <Trackings />,
    requests:      <Requests />,
    notifications: <Notifications />,
    settings:      <Settings />,
  };

  return (
    <div className="flex h-screen bg-gray-50 overflow-hidden font-sans" dir="rtl">
      <Sidebar active={page} onNavigate={setPage} />
      <main className="flex-1 overflow-y-auto p-6">
        {pages[page] || pages.dashboard}
      </main>
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <AppShell />
    </AppProvider>
  );
}
