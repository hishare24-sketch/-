import { useApp } from '../context/AppContext';

const navItems = [
  { id: 'dashboard',     icon: '◉',  label: 'الرئيسية' },
  { id: 'projects',      icon: '⬡',  label: 'المشاريع' },
  { id: 'finance',       icon: '◈',  label: 'الإدارة المالية' },
  { id: 'documents',     icon: '◻',  label: 'المستندات' },
  { id: 'trackings',     icon: '◷',  label: 'المتابعات والضمانات' },
  { id: 'requests',      icon: '◫',  label: 'الطلبات والموافقات' },
  { id: 'notifications', icon: '◌',  label: 'الإشعارات' },
  { id: 'settings',      icon: '◎',  label: 'الإعدادات' },
];

export default function Sidebar({ active, onNavigate }) {
  const { activeProject, projects, setActiveProjectId, currentUser, unreadCount } = useApp();

  return (
    <aside className="w-64 bg-gray-950 flex flex-col h-screen flex-shrink-0">
      {/* Logo */}
      <div className="px-6 py-5 border-b border-gray-800">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-blue-600 flex items-center justify-center">
            <span className="text-white font-black text-lg" style={{ fontFamily: 'serif' }}>م</span>
          </div>
          <div>
            <p className="text-white font-bold text-base leading-none">موازين</p>
            <p className="text-gray-400 text-xs mt-0.5">المنصة المالية الذكية</p>
          </div>
        </div>
      </div>

      {/* Project switcher */}
      <div className="px-4 py-3 border-b border-gray-800">
        <p className="text-gray-500 text-xs mb-2 px-2">المشروع الحالي</p>
        <div className="space-y-0.5">
          {projects.map(p => (
            <button
              key={p.id}
              onClick={() => setActiveProjectId(p.id)}
              className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-right transition-colors ${
                activeProject?.id === p.id
                  ? 'bg-gray-800 text-white'
                  : 'text-gray-400 hover:bg-gray-800/60 hover:text-gray-200'
              }`}
            >
              <span className="text-base">{p.icon}</span>
              <span className="text-sm font-medium truncate">{p.name}</span>
              {activeProject?.id === p.id && (
                <span className="mr-auto w-1.5 h-1.5 rounded-full bg-blue-400 flex-shrink-0" />
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 px-4 py-4 space-y-0.5 overflow-y-auto">
        {navItems.map(item => {
          const isActive = active === item.id;
          const hasNotif = item.id === 'notifications' && unreadCount > 0;
          const hasBadge = item.id === 'requests';
          return (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-right transition-all ${
                isActive
                  ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/20'
                  : 'text-gray-400 hover:bg-gray-800/60 hover:text-gray-200'
              }`}
            >
              <span className={`text-base w-5 text-center ${isActive ? 'text-white' : 'text-gray-500'}`}>
                {item.icon}
              </span>
              <span className="text-sm font-medium">{item.label}</span>
              {hasNotif && (
                <span className="mr-auto bg-red-500 text-white text-xs w-5 h-5 rounded-full flex items-center justify-center font-bold">
                  {unreadCount}
                </span>
              )}
              {hasBadge && !isActive && (
                <span className="mr-auto bg-yellow-500 text-white text-xs w-5 h-5 rounded-full flex items-center justify-center font-bold">
                  2
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* User */}
      <div className="px-4 py-4 border-t border-gray-800">
        <div className="flex items-center gap-3 px-2">
          <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center text-white text-sm font-bold flex-shrink-0">
            {currentUser.avatar}
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-white text-sm font-medium truncate">{currentUser.name}</p>
            <p className="text-gray-500 text-xs truncate">{currentUser.role}</p>
          </div>
          <button className="text-gray-500 hover:text-gray-300 transition-colors text-lg">⇥</button>
        </div>
      </div>
    </aside>
  );
}
