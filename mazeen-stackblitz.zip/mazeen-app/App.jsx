import { useState, createContext, useContext } from "react";

// ═══════════════════════════════════════════════════════
//  DATA
// ═══════════════════════════════════════════════════════
const currentUser = { id:"u1", name:"محمد العمري", email:"mohammed@example.com", avatar:"م", role:"مالك" };

const projects = [
  { id:"p1", name:"شركة النخيل للتجارة", type:"شركة", icon:"🏢", color:"#1e40af", description:"إدارة عمليات الشركة الرئيسية", membersCount:4, balance:284500 },
  { id:"p2", name:"مشروع المنزل",         type:"شخصي", icon:"🏠", color:"#047857", description:"مصروفات ووثائق المنزل العائلية",    membersCount:2, balance:52300  },
  { id:"p3", name:"مطعم الديوانية",       type:"مطعم", icon:"🍽️", color:"#b45309", description:"إدارة العمليات المالية للمطعم",    membersCount:3, balance:118900 },
];

const transactions = [
  { id:"t1", projectId:"p1", type:"income",  amount:85000, category:"مبيعات", description:"فاتورة مبيعات — عميل الرياض",          date:"2025-06-20", documentId:"d1", status:"completed", channel:"البنك الأهلي" },
  { id:"t2", projectId:"p1", type:"expense", amount:12400, category:"رواتب",   description:"رواتب موظفين — يونيو 2025",            date:"2025-06-18", documentId:null, status:"completed", channel:"البنك الأهلي" },
  { id:"t3", projectId:"p1", type:"expense", amount:3200,  category:"صيانة",   description:"صيانة المكيفات — شركة البرودة",        date:"2025-06-15", documentId:"d2", status:"completed", channel:"نقدي" },
  { id:"t4", projectId:"p1", type:"income",  amount:42000, category:"مبيعات", description:"فاتورة مبيعات — عميل جدة",             date:"2025-06-12", documentId:"d3", status:"completed", channel:"البنك الأهلي" },
  { id:"t5", projectId:"p1", type:"expense", amount:8900,  category:"إيجار",   description:"إيجار المكتب — يونيو 2025",            date:"2025-06-01", documentId:"d4", status:"completed", channel:"البنك الأهلي" },
  { id:"t6", projectId:"p2", type:"expense", amount:1450,  category:"فواتير",  description:"فاتورة الكهرباء",                       date:"2025-06-10", documentId:"d5", status:"completed", channel:"نقدي" },
  { id:"t7", projectId:"p3", type:"income",  amount:28000, category:"مبيعات", description:"إيرادات المطعم — أسبوع أول يونيو",     date:"2025-06-07", documentId:null, status:"completed", channel:"نقدي" },
];

const documents = [
  { id:"d1", projectId:"p1", name:"فاتورة مبيعات — عميل الرياض", type:"فاتورة",       fileType:"PDF",  uploadedAt:"2025-06-20", size:"245 KB", aiExtracted:true, status:"processed", aiData:{ vendor:"شركة الرياض للتوزيع",    amount:85000, date:"2025-06-20", warranty:null,                               items:["بضاعة تجارية","خدمات لوجستية"] } },
  { id:"d2", projectId:"p1", name:"فاتورة صيانة المكيفات",        type:"فاتورة",       fileType:"PDF",  uploadedAt:"2025-06-15", size:"180 KB", aiExtracted:true, status:"processed", aiData:{ vendor:"شركة البرودة للتكييف",   amount:3200,  date:"2025-06-15", warranty:{ months:12, expiresAt:"2026-06-15" }, items:["صيانة وحدات التكييف","قطع غيار"] } },
  { id:"d3", projectId:"p1", name:"فاتورة مبيعات — عميل جدة",    type:"فاتورة",       fileType:"PDF",  uploadedAt:"2025-06-12", size:"210 KB", aiExtracted:true, status:"processed", aiData:{ vendor:"مؤسسة جدة التجارية",     amount:42000, date:"2025-06-12", warranty:null,                               items:["بضاعة تجارية"] } },
  { id:"d4", projectId:"p1", name:"عقد إيجار المكتب",             type:"عقد",          fileType:"PDF",  uploadedAt:"2024-01-01", size:"520 KB", aiExtracted:true, status:"processed", aiData:{ vendor:"شركة العقارات الذهبية", amount:8900,  date:"2024-01-01", contractEnd:"2026-01-01",                    items:["إيجار مكتب — الدور الثالث"] } },
  { id:"d5", projectId:"p2", name:"فاتورة الكهرباء — يونيو",     type:"فاتورة",       fileType:"صورة", uploadedAt:"2025-06-10", size:"95 KB",  aiExtracted:true, status:"processed", aiData:{ vendor:"شركة الكهرباء السعودية",amount:1450,  date:"2025-06-10", warranty:null,                               items:["استهلاك الكهرباء"] } },
  { id:"d6", projectId:"p1", name:"وثيقة السجل التجاري",          type:"وثيقة رسمية", fileType:"PDF",  uploadedAt:"2024-01-15", size:"310 KB", aiExtracted:true, status:"processed", aiData:{ number:"1010123456", issuedAt:"2023-01-15", expiresAt:"2026-01-15", issuer:"وزارة التجارة" } },
];

const trackings = [
  { id:"tr1", projectId:"p1", type:"ضمان",         name:"ضمان صيانة المكيفات",       endDate:"2026-06-15", daysLeft:356,  status:"active",    vendor:"شركة البرودة للتكييف",    notes:"ضمان شامل على قطع الغيار والتركيب", alertDays:30, icon:"❄️" },
  { id:"tr2", projectId:"p1", type:"عقد",           name:"عقد إيجار المكتب",          endDate:"2026-01-01", daysLeft:191,  status:"active",    vendor:"شركة العقارات الذهبية",  notes:"إيجار سنوي — قابل للتجديد",         alertDays:60, icon:"🏢" },
  { id:"tr3", projectId:"p1", type:"وثيقة رسمية",  name:"السجل التجاري",             endDate:"2026-01-15", daysLeft:205,  status:"active",    vendor:"وزارة التجارة",            notes:"يجب التجديد قبل 30 يوم من الانتهاء",alertDays:30, icon:"📋" },
  { id:"tr4", projectId:"p1", type:"اشتراك",        name:"اشتراك Microsoft 365",      endDate:"2025-07-01", daysLeft:7,    status:"expiring",  vendor:"Microsoft",                notes:"5 مستخدمين — Business Basic",        alertDays:14, icon:"💻" },
  { id:"tr5", projectId:"p2", type:"ضمان",         name:"ضمان ثلاجة سامسونج",        endDate:"2025-03-10", daysLeft:-106, status:"expired",   vendor:"سامسونج",                  notes:"انتهى الضمان",                       alertDays:30, icon:"🧊" },
  { id:"tr6", projectId:"p1", type:"أصل",           name:"سيارة التوصيل — هايلكس",   endDate:"2025-12-01", daysLeft:160,  status:"active",    vendor:"وكالة تويوتا",             notes:"موعد الصيانة القادم: 80,000 كم",     alertDays:30, icon:"🚗" },
];

const requests0 = [
  { id:"req1", projectId:"p1", type:"مصروف", title:"طلب شراء معدات مكتبية",  amount:4500,  requestedBy:"أحمد السالم",  requestedByAvatar:"أ", date:"2025-06-22", status:"pending",   description:"شراء طابعة وكراسي مكتبية للموظفين الجدد",                  attachments:1, priority:"normal" },
  { id:"req2", projectId:"p1", type:"عهدة",  title:"عهدة سفر — مؤتمر الرياض",amount:2800,  requestedBy:"سارة المطيري", requestedByAvatar:"س", date:"2025-06-20", status:"approved",  description:"تكاليف السفر والإقامة لحضور مؤتمر التجارة الإلكترونية",    attachments:2, priority:"high" },
  { id:"req3", projectId:"p1", type:"تحويل", title:"تحويل لحساب المشغّل",    amount:15000, requestedBy:"محمد العمري",  requestedByAvatar:"م", date:"2025-06-18", status:"completed", description:"تحويل مبلغ لتغطية مصروفات التشغيل الشهرية",                 attachments:0, priority:"normal" },
  { id:"req4", projectId:"p1", type:"مصروف", title:"طلب صيانة السيارة",      amount:1200,  requestedBy:"خالد الغامدي", requestedByAvatar:"خ", date:"2025-06-23", status:"pending",   description:"صيانة دورية لسيارة التوصيل — تغيير زيت وفلاتر",           attachments:0, priority:"normal" },
];

const notifications0 = [
  { id:"n1", type:"warning", title:"اشتراك يوشك على الانتهاء", message:"اشتراك Microsoft 365 ينتهي خلال 7 أيام",                     date:"2025-06-24", read:false, icon:"⚠️" },
  { id:"n2", type:"request", title:"طلب موافقة جديد",           message:"أحمد السالم يطلب الموافقة على معدات مكتبية — 4,500 ر.س",   date:"2025-06-22", read:false, icon:"📋" },
  { id:"n3", type:"ai",      title:"تم استخراج بيانات المستند", message:"تم قراءة فاتورة مبيعات الرياض وتحليلها بنجاح",              date:"2025-06-20", read:true,  icon:"🤖" },
  { id:"n4", type:"success", title:"تمت الموافقة على الطلب",    message:"تمت الموافقة على عهدة سفر سارة المطيري",                    date:"2025-06-21", read:true,  icon:"✅" },
  { id:"n5", type:"info",    title:"تذكير — عقد الإيجار",       message:"عقد إيجار المكتب ينتهي بعد 191 يوماً — يناير 2026",        date:"2025-06-15", read:true,  icon:"📅" },
];

const monthlyData = [
  { month:"يناير", income:95000,  expenses:18000 },
  { month:"فبراير", income:88000, expenses:21000 },
  { month:"مارس",  income:112000, expenses:19500 },
  { month:"أبريل", income:98000,  expenses:22000 },
  { month:"مايو",  income:115000, expenses:20000 },
  { month:"يونيو", income:127000, expenses:24500 },
];

// ═══════════════════════════════════════════════════════
//  CONTEXT
// ═══════════════════════════════════════════════════════
const AppCtx = createContext();
function useApp() { return useContext(AppCtx); }

function AppProvider({ children }) {
  const [activePid, setActivePid] = useState("p1");
  const [notifs, setNotifs] = useState(notifications0);
  const [reqs, setReqs]     = useState(requests0);
  const activeProject = projects.find(p => p.id === activePid);
  const unread = notifs.filter(n => !n.read).length;
  const markRead    = (id) => setNotifs(n => n.map(x => x.id === id ? { ...x, read:true } : x));
  const markAllRead = ()   => setNotifs(n => n.map(x => ({ ...x, read:true })));
  const approveReq  = (id) => setReqs(r => r.map(x => x.id === id ? { ...x, status:"approved"  } : x));
  const rejectReq   = (id) => setReqs(r => r.map(x => x.id === id ? { ...x, status:"rejected"  } : x));
  return (
    <AppCtx.Provider value={{ currentUser, projects, activeProject, activePid, setActivePid, notifs, unread, markRead, markAllRead, reqs, approveReq, rejectReq }}>
      {children}
    </AppCtx.Provider>
  );
}

// ═══════════════════════════════════════════════════════
//  HELPERS / ATOMS
// ═══════════════════════════════════════════════════════
const fmt  = (n) => n.toLocaleString("ar-SA") + " ر.س";
const fmtD = (s) => s ? new Date(s).toLocaleDateString("ar-SA", { year:"numeric", month:"short", day:"numeric" }) : "—";

function Badge({ label, color="blue" }) {
  const c = { blue:"bg-blue-50 text-blue-700", green:"bg-green-50 text-green-700", red:"bg-red-50 text-red-700", yellow:"bg-yellow-50 text-yellow-700", gray:"bg-gray-100 text-gray-600", orange:"bg-orange-50 text-orange-700", purple:"bg-purple-50 text-purple-700" };
  return <span className={`text-xs font-medium px-2.5 py-1 rounded-full ${c[color]||c.blue}`}>{label}</span>;
}

function SBadge({ status }) {
  const m = { active:{l:"نشط",color:"green"}, expiring:{l:"يوشك على الانتهاء",color:"yellow"}, expired:{l:"منتهي",color:"red"}, pending:{l:"قيد المراجعة",color:"yellow"}, approved:{l:"معتمد",color:"green"}, completed:{l:"مكتمل",color:"blue"}, rejected:{l:"مرفوض",color:"red"}, processed:{l:"تم المعالجة",color:"green"} };
  const s = m[status] || { l:status, color:"gray" };
  return <Badge label={s.l} color={s.color} />;
}

function Btn({ children, v="primary", sz="md", onClick, className="", disabled=false }) {
  const vs = { primary:"bg-blue-600 text-white hover:bg-blue-700 shadow-sm", secondary:"bg-gray-100 text-gray-700 hover:bg-gray-200", danger:"bg-red-600 text-white hover:bg-red-700", ghost:"text-gray-600 hover:bg-gray-100", outline:"border border-gray-300 text-gray-700 hover:bg-gray-50", success:"bg-green-600 text-white hover:bg-green-700" };
  const ss = { sm:"px-3 py-1.5 text-xs", md:"px-4 py-2 text-sm", lg:"px-6 py-3 text-base" };
  return <button onClick={onClick} disabled={disabled} className={`${vs[v]} ${ss[sz]} rounded-xl font-medium transition-colors flex items-center gap-2 ${disabled?"opacity-50 cursor-not-allowed":""} ${className}`}>{children}</button>;
}

function Card({ children, className="", onClick }) {
  return <div onClick={onClick} className={`bg-white rounded-2xl shadow-sm border border-gray-100 ${onClick?"cursor-pointer hover:shadow-md transition-shadow":""} ${className}`}>{children}</div>;
}

function PageHeader({ title, subtitle, actions }) {
  return (
    <div className="flex items-center justify-between mb-6">
      <div><h1 className="text-2xl font-bold text-gray-900">{title}</h1>{subtitle && <p className="text-sm text-gray-500 mt-1">{subtitle}</p>}</div>
      {actions && <div className="flex items-center gap-2">{actions}</div>}
    </div>
  );
}

// ═══════════════════════════════════════════════════════
//  SIDEBAR
// ═══════════════════════════════════════════════════════
const navItems = [
  { id:"dashboard",     icon:"◉", label:"الرئيسية" },
  { id:"projects",      icon:"⬡", label:"المشاريع" },
  { id:"finance",       icon:"◈", label:"الإدارة المالية" },
  { id:"documents",     icon:"◻", label:"المستندات" },
  { id:"trackings",     icon:"◷", label:"المتابعات والضمانات" },
  { id:"requests",      icon:"◫", label:"الطلبات والموافقات" },
  { id:"notifications", icon:"◌", label:"الإشعارات" },
  { id:"settings",      icon:"◎", label:"الإعدادات" },
];

function Sidebar({ active, onNav }) {
  const { activeProject, projects, setActivePid, currentUser, unread, reqs } = useApp();
  const pendingCount = reqs.filter(r => r.status === "pending").length;
  return (
    <aside className="w-64 bg-gray-950 flex flex-col h-screen flex-shrink-0">
      <div className="px-6 py-5 border-b border-gray-800">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-blue-600 flex items-center justify-center"><span className="text-white font-black text-lg" style={{fontFamily:"serif"}}>م</span></div>
          <div><p className="text-white font-bold text-base leading-none">موازين</p><p className="text-gray-400 text-xs mt-0.5">المنصة المالية الذكية</p></div>
        </div>
      </div>

      <div className="px-4 py-3 border-b border-gray-800">
        <p className="text-gray-500 text-xs mb-2 px-2">المشروع الحالي</p>
        {projects.map(p => (
          <button key={p.id} onClick={() => setActivePid(p.id)} className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-right transition-colors mb-0.5 ${activeProject?.id===p.id?"bg-gray-800 text-white":"text-gray-400 hover:bg-gray-800/60 hover:text-gray-200"}`}>
            <span>{p.icon}</span><span className="text-sm font-medium truncate">{p.name}</span>
            {activeProject?.id===p.id && <span className="mr-auto w-1.5 h-1.5 rounded-full bg-blue-400 flex-shrink-0"/>}
          </button>
        ))}
      </div>

      <nav className="flex-1 px-4 py-4 space-y-0.5 overflow-y-auto">
        {navItems.map(item => {
          const isActive = active === item.id;
          return (
            <button key={item.id} onClick={() => onNav(item.id)} className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-right transition-all ${isActive?"bg-blue-600 text-white shadow-lg shadow-blue-600/20":"text-gray-400 hover:bg-gray-800/60 hover:text-gray-200"}`}>
              <span className={`text-base w-5 text-center ${isActive?"text-white":"text-gray-500"}`}>{item.icon}</span>
              <span className="text-sm font-medium">{item.label}</span>
              {item.id==="notifications" && unread > 0 && <span className="mr-auto bg-red-500 text-white text-xs w-5 h-5 rounded-full flex items-center justify-center font-bold">{unread}</span>}
              {item.id==="requests" && pendingCount > 0 && !isActive && <span className="mr-auto bg-yellow-500 text-white text-xs w-5 h-5 rounded-full flex items-center justify-center font-bold">{pendingCount}</span>}
            </button>
          );
        })}
      </nav>

      <div className="px-4 py-4 border-t border-gray-800">
        <div className="flex items-center gap-3 px-2">
          <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center text-white text-sm font-bold flex-shrink-0">{currentUser.avatar}</div>
          <div className="min-w-0 flex-1"><p className="text-white text-sm font-medium truncate">{currentUser.name}</p><p className="text-gray-500 text-xs">{currentUser.role}</p></div>
        </div>
      </div>
    </aside>
  );
}

// ═══════════════════════════════════════════════════════
//  DASHBOARD
// ═══════════════════════════════════════════════════════
function BarChart({ data }) {
  const max = Math.max(...data.map(d => Math.max(d.income, d.expenses)));
  return (
    <div className="flex items-end gap-2 h-32">
      {data.map((d, i) => (
        <div key={i} className="flex-1 flex flex-col items-center gap-1">
          <div className="w-full flex items-end gap-0.5" style={{height:"100px"}}>
            <div className="flex-1 bg-blue-500 rounded-t-sm opacity-90" style={{height:`${(d.income/max)*100}%`}}/>
            <div className="flex-1 bg-red-400 rounded-t-sm opacity-80" style={{height:`${(d.expenses/max)*100}%`}}/>
          </div>
          <span className="text-xs text-gray-400">{d.month.slice(0,3)}</span>
        </div>
      ))}
    </div>
  );
}

function Dashboard({ onNav }) {
  const { activeProject } = useApp();
  const ptxns = transactions.filter(t => t.projectId === activeProject?.id).slice(0,5);
  const urgent = trackings.filter(t => (t.status==="expiring"||t.status==="expired") && t.projectId===activeProject?.id).slice(0,3);
  const pending = requests0.filter(r => r.status==="pending" && r.projectId===activeProject?.id).slice(0,2);
  const totalIn  = transactions.filter(t=>t.projectId===activeProject?.id&&t.type==="income").reduce((s,t)=>s+t.amount,0);
  const totalEx  = transactions.filter(t=>t.projectId===activeProject?.id&&t.type==="expense").reduce((s,t)=>s+t.amount,0);
  const expCats  = [{ cat:"رواتب",amount:12400,pct:51 },{ cat:"إيجار",amount:8900,pct:36 },{ cat:"صيانة",amount:3200,pct:13 }];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div><h1 className="text-2xl font-bold text-gray-900">لوحة التحكم</h1><p className="text-sm text-gray-500 mt-1">{activeProject?.name} — يونيو 2025</p></div>
        <div className="flex gap-2"><Btn v="outline" sz="sm">📊 تقرير شهري</Btn><Btn sz="sm" onClick={()=>onNav("documents")}>+ رفع مستند</Btn></div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4">
        {[
          { l:"الرصيد الكلي",          v:fmt(activeProject?.balance||0), icon:"💰", bg:"bg-blue-50",   txt:"text-blue-700",   ibc:"bg-blue-100 text-blue-600" },
          { l:"إيرادات الشهر",         v:fmt(totalIn),                   icon:"📈", bg:"bg-green-50",  txt:"text-green-700",  ibc:"bg-green-100 text-green-600" },
          { l:"مصروفات الشهر",         v:fmt(totalEx),                   icon:"📉", bg:"bg-red-50",    txt:"text-red-700",    ibc:"bg-red-100 text-red-600" },
          { l:"طلبات معلقة",           v:"2",                            icon:"⏳", bg:"bg-yellow-50", txt:"text-yellow-700", ibc:"bg-yellow-100 text-yellow-600" },
          { l:"متابعات تنتهي قريباً", v:"1",                            icon:"⚠️", bg:"bg-orange-50", txt:"text-orange-700", ibc:"bg-orange-100 text-orange-600" },
          { l:"المشاريع النشطة",       v:"3",                            icon:"⬡", bg:"bg-purple-50", txt:"text-purple-700", ibc:"bg-purple-100 text-purple-600" },
        ].map((s,i) => (
          <div key={i} className={`${s.bg} rounded-2xl p-5 flex items-center gap-4`}>
            <div className={`${s.ibc} w-12 h-12 rounded-xl flex items-center justify-center text-xl flex-shrink-0`}>{s.icon}</div>
            <div><p className="text-xs text-gray-500 mb-0.5">{s.l}</p><p className={`text-xl font-bold ${s.txt} leading-tight`}>{s.v}</p></div>
          </div>
        ))}
      </div>

      {/* Chart row */}
      <div className="grid grid-cols-5 gap-4">
        <Card className="col-span-3 p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-gray-800">الإيرادات والمصروفات</h3>
            <div className="flex gap-4 text-xs text-gray-500">
              <span className="flex items-center gap-1.5"><span className="w-3 h-3 rounded-sm bg-blue-500 inline-block"/>إيرادات</span>
              <span className="flex items-center gap-1.5"><span className="w-3 h-3 rounded-sm bg-red-400 inline-block"/>مصروفات</span>
            </div>
          </div>
          <BarChart data={monthlyData}/>
        </Card>
        <Card className="col-span-2 p-5">
          <h3 className="font-semibold text-gray-800 mb-4">توزيع المصروفات</h3>
          <div className="space-y-3">
            {expCats.map((c,i) => (
              <div key={i}>
                <div className="flex justify-between text-sm mb-1"><span className="text-gray-600">{c.cat}</span><span className="font-medium">{c.pct}%</span></div>
                <div className="h-2 bg-gray-100 rounded-full overflow-hidden"><div className="h-full rounded-full" style={{width:`${c.pct}%`, backgroundColor:["#3b82f6","#10b981","#f59e0b"][i]}}/></div>
                <p className="text-xs text-gray-400 mt-0.5">{fmt(c.amount)}</p>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Bottom row */}
      <div className="grid grid-cols-3 gap-4">
        <Card className="p-5">
          <div className="flex items-center justify-between mb-4"><h3 className="font-semibold text-gray-800">آخر العمليات</h3><button onClick={()=>onNav("finance")} className="text-xs text-blue-600 hover:underline">عرض الكل</button></div>
          <div className="space-y-3">
            {ptxns.map(t => (
              <div key={t.id} className="flex items-center gap-3">
                <div className={`w-8 h-8 rounded-lg flex items-center justify-center text-sm flex-shrink-0 ${t.type==="income"?"bg-green-50 text-green-600":"bg-red-50 text-red-500"}`}>{t.type==="income"?"↑":"↓"}</div>
                <div className="flex-1 min-w-0"><p className="text-sm text-gray-700 truncate">{t.description}</p><p className="text-xs text-gray-400">{fmtD(t.date)}</p></div>
                <p className={`text-sm font-semibold flex-shrink-0 ${t.type==="income"?"text-green-600":"text-red-500"}`}>{t.type==="income"?"+":"-"}{t.amount.toLocaleString()}</p>
              </div>
            ))}
          </div>
        </Card>

        <Card className="p-5">
          <div className="flex items-center justify-between mb-4"><h3 className="font-semibold text-gray-800">تنبيهات المتابعات</h3><button onClick={()=>onNav("trackings")} className="text-xs text-blue-600 hover:underline">عرض الكل</button></div>
          <div className="space-y-3">
            {urgent.map(t => (
              <div key={t.id} className={`flex items-center gap-3 p-3 rounded-xl ${t.status==="expired"?"bg-red-50":"bg-yellow-50"}`}>
                <span className="text-xl">{t.icon}</span>
                <div className="flex-1 min-w-0"><p className="text-sm font-medium text-gray-800 truncate">{t.name}</p><p className={`text-xs ${t.status==="expired"?"text-red-600":"text-yellow-700"}`}>{t.status==="expired"?"انتهى الضمان":`يوشك على الانتهاء — ${t.daysLeft} يوم`}</p></div>
              </div>
            ))}
          </div>
        </Card>

        <Card className="p-5">
          <div className="flex items-center justify-between mb-4"><h3 className="font-semibold text-gray-800">طلبات تنتظر موافقتك</h3><button onClick={()=>onNav("requests")} className="text-xs text-blue-600 hover:underline">عرض الكل</button></div>
          <div className="space-y-3">
            {pending.map(r => (
              <div key={r.id} className="p-3 bg-yellow-50 rounded-xl">
                <div className="flex items-start justify-between gap-2"><p className="text-sm font-medium text-gray-800 leading-snug">{r.title}</p><span className="text-sm font-bold text-gray-700 flex-shrink-0">{r.amount.toLocaleString()}</span></div>
                <p className="text-xs text-gray-500 mt-1">من: {r.requestedBy}</p>
                <div className="flex gap-2 mt-2">
                  <button className="flex-1 bg-green-600 text-white text-xs py-1.5 rounded-lg font-medium hover:bg-green-700">موافقة</button>
                  <button className="flex-1 bg-red-50 text-red-600 text-xs py-1.5 rounded-lg font-medium hover:bg-red-100">رفض</button>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════
//  FINANCE
// ═══════════════════════════════════════════════════════
function Finance() {
  const { activeProject } = useApp();
  const [tab, setTab] = useState("الكل");
  const [cat, setCat] = useState("الكل");
  const [sel, setSel] = useState(null);
  const tabs = ["الكل","إيرادات","مصروفات"];
  const cats = ["الكل","مبيعات","رواتب","إيجار","صيانة","فواتير"];
  const ptxns = transactions.filter(t => t.projectId === activeProject?.id);
  const filtered = ptxns.filter(t => {
    const tm = tab==="الكل"||(tab==="إيرادات"&&t.type==="income")||(tab==="مصروفات"&&t.type==="expense");
    const cm = cat==="الكل"||t.category===cat;
    return tm && cm;
  });
  const totalIn  = ptxns.filter(t=>t.type==="income").reduce((s,t)=>s+t.amount,0);
  const totalEx  = ptxns.filter(t=>t.type==="expense").reduce((s,t)=>s+t.amount,0);

  return (
    <div className="space-y-5">
      <PageHeader title="الإدارة المالية" subtitle={activeProject?.name} actions={<><Btn v="outline" sz="sm">📥 تصدير</Btn><Btn sz="sm">+ عملية جديدة</Btn></>}/>
      <div className="grid grid-cols-3 gap-4">
        {[{l:"إجمالي الإيرادات",v:totalIn,clr:"text-green-600",bg:"bg-green-50",icon:"📈"},{l:"إجمالي المصروفات",v:totalEx,clr:"text-red-600",bg:"bg-red-50",icon:"📉"},{l:"صافي الربح",v:totalIn-totalEx,clr:"text-blue-600",bg:"bg-blue-50",icon:"💰"}].map((s,i)=>(
          <div key={i} className={`${s.bg} rounded-2xl p-5 flex items-center gap-4`}><span className="text-3xl">{s.icon}</span><div><p className="text-xs text-gray-500">{s.l}</p><p className={`text-xl font-bold ${s.clr}`}>{fmt(s.v)}</p></div></div>
        ))}
      </div>
      <div className="flex gap-4">
        <Card className="flex-1 p-5">
          <div className="flex gap-1 mb-4 bg-gray-100 p-1 rounded-xl w-fit">
            {tabs.map(t=><button key={t} onClick={()=>setTab(t)} className={`px-4 py-1.5 rounded-lg text-sm font-medium transition-colors ${tab===t?"bg-white text-gray-900 shadow-sm":"text-gray-500 hover:text-gray-700"}`}>{t}</button>)}
          </div>
          <div className="flex flex-wrap gap-2 mb-4">
            {cats.map(c=><button key={c} onClick={()=>setCat(c)} className={`px-3 py-1 rounded-full text-xs font-medium border transition-colors ${cat===c?"bg-blue-600 text-white border-blue-600":"border-gray-200 text-gray-600 hover:border-blue-300"}`}>{c}</button>)}
          </div>
          <table className="w-full text-sm">
            <thead><tr className="border-b border-gray-100">{["الوصف","التصنيف","التاريخ","المبلغ","مستند"].map(h=><th key={h} className="text-right py-2 font-medium text-gray-500">{h}</th>)}</tr></thead>
            <tbody>
              {filtered.map(t=>(
                <tr key={t.id} onClick={()=>setSel(t)} className={`border-b border-gray-50 hover:bg-gray-50 cursor-pointer transition-colors ${sel?.id===t.id?"bg-blue-50":""}`}>
                  <td className="py-3"><div className="flex items-center gap-2"><span className={`w-7 h-7 rounded-lg flex items-center justify-center text-xs ${t.type==="income"?"bg-green-100 text-green-600":"bg-red-100 text-red-500"}`}>{t.type==="income"?"↑":"↓"}</span><span className="text-gray-700">{t.description}</span></div></td>
                  <td className="py-3"><Badge label={t.category} color="gray"/></td>
                  <td className="py-3 text-gray-500">{fmtD(t.date)}</td>
                  <td className={`py-3 font-semibold ${t.type==="income"?"text-green-600":"text-red-500"}`}>{t.type==="income"?"+":"-"}{t.amount.toLocaleString()} ر.س</td>
                  <td className="py-3">{t.documentId?<span className="text-blue-500 text-xs bg-blue-50 px-2 py-0.5 rounded-full">📄 مرفق</span>:<span className="text-gray-300 text-xs">—</span>}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
        {sel && (
          <Card className="w-64 p-5 flex-shrink-0">
            <div className="flex items-center justify-between mb-4"><h3 className="font-semibold text-gray-800">تفاصيل العملية</h3><button onClick={()=>setSel(null)} className="text-gray-400 hover:text-gray-600">✕</button></div>
            <div className={`w-12 h-12 rounded-xl flex items-center justify-center text-xl mb-4 ${sel.type==="income"?"bg-green-100":"bg-red-100"}`}>{sel.type==="income"?"📈":"📉"}</div>
            <p className="text-lg font-bold text-gray-900 mb-1">{fmt(sel.amount)}</p>
            <p className="text-sm text-gray-500 mb-4">{sel.description}</p>
            <div className="space-y-3 text-sm">
              {[["التصنيف",sel.category],["التاريخ",fmtD(sel.date)],["القناة",sel.channel],["الحالة",<SBadge status={sel.status}/>]].map(([k,v])=>(
                <div key={k} className="flex justify-between items-center"><span className="text-gray-500">{k}</span><span className="font-medium text-gray-800">{v}</span></div>
              ))}
            </div>
          </Card>
        )}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════
//  DOCUMENTS
// ═══════════════════════════════════════════════════════
function Documents({ onNav }) {
  const { activeProject } = useApp();
  const [sel, setSel]       = useState(null);
  const [uploading, setUpl] = useState(false);
  const [aiProc, setAiP]   = useState(false);
  const [filter, setFilter] = useState("الكل");
  const types = ["الكل","فاتورة","عقد","وثيقة رسمية"];
  const pdocs  = documents.filter(d => d.projectId === activeProject?.id);
  const filtered = pdocs.filter(d => filter==="الكل"||d.type===filter);
  const tIcon = (t) => ({"فاتورة":"🧾","عقد":"📝","وثيقة رسمية":"📋","صورة":"🖼️"})[t]||"📄";

  const simulate = () => {
    setUpl(true); setSel(null);
    setTimeout(()=>{ setUpl(false); setAiP(true); }, 1500);
    setTimeout(()=>{ setAiP(false); setSel(documents[1]); }, 3500);
  };

  return (
    <div className="space-y-5">
      <PageHeader title="المستندات" subtitle={`${filtered.length} مستند — ${activeProject?.name}`} actions={<Btn sz="sm" onClick={simulate} disabled={uploading||aiProc}>{uploading?"⏳ جارٍ الرفع...":aiProc?"🤖 يحلل الذكاء الاصطناعي...":"+ رفع مستند"}</Btn>}/>

      {aiProc && (
        <div className="bg-blue-50 border border-blue-200 rounded-2xl p-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-blue-100 flex items-center justify-center text-xl">🤖</div>
          <div><p className="font-medium text-blue-800">الذكاء الاصطناعي يقرأ المستند...</p><p className="text-sm text-blue-600">جارٍ استخراج البيانات والتفاصيل تلقائياً</p></div>
          <div className="mr-auto flex gap-1">{[0,1,2].map(i=><div key={i} className="w-2 h-2 bg-blue-500 rounded-full animate-bounce" style={{animationDelay:`${i*0.15}s`}}/>)}</div>
        </div>
      )}

      <div onClick={simulate} className="border-2 border-dashed border-gray-200 rounded-2xl p-8 text-center cursor-pointer hover:border-blue-400 hover:bg-blue-50/30 transition-all">
        <div className="text-4xl mb-2">📂</div>
        <p className="font-medium text-gray-700">اسحب الملف هنا أو انقر للرفع</p>
        <p className="text-sm text-gray-400 mt-1">PDF، صور (JPG، PNG) — الحد الأقصى 20 ميغابايت</p>
        <p className="text-xs text-blue-500 mt-2">🤖 سيقوم الذكاء الاصطناعي بقراءة المستند وتحليله تلقائياً</p>
      </div>

      <div className="flex gap-4">
        <Card className="flex-1 p-5">
          <div className="flex gap-2 mb-4">{types.map(t=><button key={t} onClick={()=>setFilter(t)} className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${filter===t?"bg-blue-600 text-white":"bg-gray-100 text-gray-600 hover:bg-gray-200"}`}>{tIcon(t!=="الكل"?t:"")} {t}</button>)}</div>
          <div className="space-y-2">
            {filtered.map(doc=>(
              <div key={doc.id} onClick={()=>setSel(doc)} className={`flex items-center gap-4 p-4 rounded-xl cursor-pointer transition-all border ${sel?.id===doc.id?"border-blue-200 bg-blue-50":"border-transparent hover:bg-gray-50"}`}>
                <div className="w-10 h-12 bg-gray-100 rounded-lg flex items-center justify-center text-xl flex-shrink-0">{tIcon(doc.fileType==="صورة"?"صورة":doc.type)}</div>
                <div className="flex-1 min-w-0"><p className="font-medium text-gray-800 truncate">{doc.name}</p><div className="flex items-center gap-3 mt-1"><span className="text-xs text-gray-400">{fmtD(doc.uploadedAt)}</span><span className="text-xs text-gray-400">{doc.size}</span><Badge label={doc.type} color="gray"/></div></div>
                <div className="flex flex-col items-end gap-1 flex-shrink-0"><SBadge status={doc.status}/>{doc.aiExtracted&&<span className="text-xs text-blue-500 bg-blue-50 px-2 py-0.5 rounded-full">🤖 AI</span>}</div>
              </div>
            ))}
          </div>
        </Card>

        {sel && (
          <Card className="w-80 p-5 flex-shrink-0">
            <div className="flex items-center justify-between mb-4"><h3 className="font-semibold text-gray-800">نتائج الذكاء الاصطناعي</h3><button onClick={()=>setSel(null)} className="text-gray-400 hover:text-gray-600">✕</button></div>
            <div className="bg-blue-50 rounded-xl p-3 mb-4 flex items-center gap-2"><span className="text-xl">🤖</span><div><p className="text-xs font-semibold text-blue-700">تم استخراج البيانات تلقائياً</p><p className="text-xs text-blue-500">بدقة عالية — يُرجى المراجعة</p></div></div>
            <p className="font-semibold text-gray-800 mb-3 truncate">{sel.name}</p>
            <div className="space-y-3 text-sm mb-4">
              {sel.aiData?.vendor&&<div className="flex justify-between"><span className="text-gray-500">المورد</span><span className="font-medium text-gray-800">{sel.aiData.vendor}</span></div>}
              {sel.aiData?.amount&&<div className="flex justify-between"><span className="text-gray-500">المبلغ</span><span className="font-bold text-blue-700">{fmt(sel.aiData.amount)}</span></div>}
              {sel.aiData?.date&&<div className="flex justify-between"><span className="text-gray-500">التاريخ</span><span className="font-medium">{fmtD(sel.aiData.date)}</span></div>}
              {sel.aiData?.contractEnd&&<div className="flex justify-between"><span className="text-gray-500">انتهاء العقد</span><span className="font-medium text-orange-600">{fmtD(sel.aiData.contractEnd)}</span></div>}
              {sel.aiData?.warranty&&<div className="bg-yellow-50 rounded-xl p-3"><p className="text-xs font-semibold text-yellow-700 mb-1">⚠️ تم اكتشاف ضمان</p><p className="text-xs text-yellow-600">مدة الضمان: {sel.aiData.warranty.months} شهراً</p><p className="text-xs text-yellow-600">ينتهي في: {fmtD(sel.aiData.warranty.expiresAt)}</p></div>}
              {sel.aiData?.items&&<div><p className="text-gray-500 mb-1">البنود</p>{sel.aiData.items.map((item,i)=><p key={i} className="text-xs text-gray-600 bg-gray-50 px-2 py-1 rounded-lg mb-1">• {item}</p>)}</div>}
              {sel.aiData?.number&&<div className="flex justify-between"><span className="text-gray-500">رقم الوثيقة</span><span className="font-medium">{sel.aiData.number}</span></div>}
              {sel.aiData?.expiresAt&&<div className="flex justify-between"><span className="text-gray-500">تاريخ الانتهاء</span><span className="font-medium text-orange-600">{fmtD(sel.aiData.expiresAt)}</span></div>}
            </div>
            <div className="border-t border-gray-100 pt-4 space-y-2">
              <p className="text-xs text-gray-500 mb-2 font-medium">إجراءات مقترحة:</p>
              <Btn sz="sm" className="w-full justify-center">✅ إنشاء عملية مالية</Btn>
              {sel.aiData?.warranty&&<Btn v="outline" sz="sm" className="w-full justify-center">🔔 إضافة متابعة ضمان</Btn>}
              {sel.aiData?.contractEnd&&<Btn v="outline" sz="sm" className="w-full justify-center">📅 إضافة تنبيه العقد</Btn>}
              {sel.aiData?.expiresAt&&<Btn v="outline" sz="sm" className="w-full justify-center">📅 إضافة تنبيه التجديد</Btn>}
              <Btn v="ghost" sz="sm" className="w-full justify-center text-gray-400">تجاهل</Btn>
            </div>
          </Card>
        )}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════
//  TRACKINGS
// ═══════════════════════════════════════════════════════
function Trackings() {
  const { activeProject } = useApp();
  const [filter, setFilter] = useState("الكل");
  const [sel, setSel]       = useState(null);
  const types = ["الكل","ضمان","عقد","وثيقة رسمية","اشتراك","أصل"];
  const tclr  = {"ضمان":"blue","عقد":"purple","وثيقة رسمية":"green","اشتراك":"orange","أصل":"gray"};
  const pt    = trackings.filter(t => t.projectId === activeProject?.id);
  const filtered = pt.filter(t => filter==="الكل"||t.type===filter);
  const dclr  = (days,status) => status==="expired"?"text-red-600 bg-red-50":days<=14?"text-yellow-700 bg-yellow-50":days<=60?"text-orange-600 bg-orange-50":"text-green-700 bg-green-50";
  const dlbl  = (days,status) => status==="expired"?`منتهي منذ ${Math.abs(days)} يوم`:`${days} يوم متبقية`;

  return (
    <div className="space-y-5">
      <PageHeader title="المتابعات والضمانات" subtitle={`${filtered.length} عنصر`} actions={<Btn sz="sm">+ إضافة متابعة</Btn>}/>
      <div className="grid grid-cols-4 gap-3">
        {[{l:"نشط",cnt:pt.filter(t=>t.status==="active").length,bg:"bg-green-50",tc:"text-green-700",icon:"✅"},{l:"يوشك على الانتهاء",cnt:pt.filter(t=>t.status==="expiring").length,bg:"bg-yellow-50",tc:"text-yellow-700",icon:"⚠️"},{l:"منتهي",cnt:pt.filter(t=>t.status==="expired").length,bg:"bg-red-50",tc:"text-red-700",icon:"❌"},{l:"إجمالي العناصر",cnt:pt.length,bg:"bg-blue-50",tc:"text-blue-700",icon:"📋"}].map((s,i)=>(
          <div key={i} className={`${s.bg} rounded-2xl p-4`}><p className="text-2xl mb-1">{s.icon}</p><p className={`text-2xl font-bold ${s.tc}`}>{s.cnt}</p><p className="text-xs text-gray-500">{s.l}</p></div>
        ))}
      </div>
      <div className="flex gap-2 flex-wrap">{types.map(t=><button key={t} onClick={()=>setFilter(t)} className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${filter===t?"bg-blue-600 text-white":"bg-gray-100 text-gray-600 hover:bg-gray-200"}`}>{t}</button>)}</div>
      <div className="flex gap-4">
        <div className="flex-1 grid grid-cols-2 gap-3 content-start">
          {filtered.map(item=>(
            <Card key={item.id} onClick={()=>setSel(item)} className={`p-4 border-2 transition-all ${sel?.id===item.id?"border-blue-300":"border-transparent"}`}>
              <div className="flex items-start justify-between mb-3"><span className="text-2xl">{item.icon}</span><SBadge status={item.status}/></div>
              <p className="font-semibold text-gray-800 mb-1 leading-snug">{item.name}</p>
              <p className="text-xs text-gray-400 mb-3">{item.vendor}</p>
              <div className={`text-xs font-semibold px-2 py-1 rounded-lg w-fit mb-3 ${dclr(item.daysLeft,item.status)}`}>{dlbl(item.daysLeft,item.status)}</div>
              <div className="flex items-center justify-between text-xs text-gray-400"><span>ينتهي: {fmtD(item.endDate)}</span><Badge label={item.type} color={tclr[item.type]||"gray"}/></div>
            </Card>
          ))}
        </div>
        {sel && (
          <Card className="w-72 p-5 flex-shrink-0">
            <div className="flex items-center justify-between mb-4"><h3 className="font-semibold text-gray-800">التفاصيل</h3><button onClick={()=>setSel(null)} className="text-gray-400 hover:text-gray-600">✕</button></div>
            <div className="text-4xl text-center mb-4">{sel.icon}</div>
            <p className="font-bold text-gray-800 text-center mb-1">{sel.name}</p>
            <p className="text-sm text-gray-400 text-center mb-4">{sel.vendor}</p>
            <div className={`text-center text-sm font-semibold py-2 rounded-xl mb-4 ${dclr(sel.daysLeft,sel.status)}`}>{dlbl(sel.daysLeft,sel.status)}</div>
            <div className="space-y-2 text-sm border-t border-gray-100 pt-4">
              {[["النوع",<Badge label={sel.type} color={tclr[sel.type]||"gray"}/>],["الحالة",<SBadge status={sel.status}/>],["تاريخ الانتهاء",fmtD(sel.endDate)],["التنبيه قبل",`${sel.alertDays} يوم`]].map(([k,v])=>(
                <div key={k} className="flex justify-between items-center"><span className="text-gray-500">{k}</span><span className="font-medium">{v}</span></div>
              ))}
            </div>
            {sel.notes&&<div className="mt-4 bg-gray-50 rounded-xl p-3 text-xs text-gray-600">📝 {sel.notes}</div>}
            <div className="space-y-2 mt-4">
              <Btn sz="sm" className="w-full justify-center">🔔 تعديل التنبيه</Btn>
              {sel.status==="expiring"&&<Btn v="success" sz="sm" className="w-full justify-center">♻️ تجديد</Btn>}
              <Btn v="outline" sz="sm" className="w-full justify-center">📄 عرض المستند</Btn>
            </div>
          </Card>
        )}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════
//  REQUESTS
// ═══════════════════════════════════════════════════════
function Requests() {
  const { activeProject, reqs, approveReq, rejectReq } = useApp();
  const [tab, setTab] = useState("الكل");
  const [sel, setSel] = useState(null);
  const tabs = ["الكل","قيد المراجعة","معتمد","مكتمل"];
  const tIcon = {"مصروف":"💸","عهدة":"🧾","تحويل":"🔄"};
  const pr = (p) => ({"high":{l:"عاجل",c:"red"},normal:{l:"عادي",c:"gray"}})[p]||{l:p,c:"gray"};
  const preqs = reqs.filter(r=>r.projectId===activeProject?.id);
  const filtered = preqs.filter(r => tab==="الكل"||(tab==="قيد المراجعة"&&r.status==="pending")||(tab==="معتمد"&&r.status==="approved")||(tab==="مكتمل"&&r.status==="completed"));

  return (
    <div className="space-y-5">
      <PageHeader title="الطلبات والموافقات" subtitle={`${preqs.filter(r=>r.status==="pending").length} طلب معلق`} actions={<Btn sz="sm">+ طلب جديد</Btn>}/>
      <div className="flex gap-1 bg-gray-100 p-1 rounded-xl w-fit">{tabs.map(t=><button key={t} onClick={()=>setTab(t)} className={`px-4 py-1.5 rounded-lg text-sm font-medium transition-colors ${tab===t?"bg-white text-gray-900 shadow-sm":"text-gray-500 hover:text-gray-700"}`}>{t}</button>)}</div>
      <div className="flex gap-4">
        <Card className="flex-1 p-5">
          <div className="space-y-3">
            {filtered.map(req=>(
              <div key={req.id} onClick={()=>setSel(req)} className={`flex items-center gap-4 p-4 rounded-xl cursor-pointer border-2 transition-all ${sel?.id===req.id?"border-blue-200 bg-blue-50":"border-transparent hover:bg-gray-50"}`}>
                <div className="w-10 h-10 bg-gray-100 rounded-xl flex items-center justify-center text-xl flex-shrink-0">{tIcon[req.type]||"📋"}</div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-0.5"><p className="font-medium text-gray-800 truncate">{req.title}</p><Badge label={pr(req.priority).l} color={pr(req.priority).c}/></div>
                  <p className="text-xs text-gray-400">من: {req.requestedBy} · {fmtD(req.date)}</p>
                </div>
                <div className="flex flex-col items-end gap-2 flex-shrink-0"><p className="font-bold text-gray-800">{fmt(req.amount)}</p><SBadge status={req.status}/></div>
              </div>
            ))}
          </div>
        </Card>
        {sel && (
          <Card className="w-72 p-5 flex-shrink-0">
            <div className="flex items-center justify-between mb-4"><h3 className="font-semibold text-gray-800">تفاصيل الطلب</h3><button onClick={()=>setSel(null)} className="text-gray-400 hover:text-gray-600">✕</button></div>
            <div className="text-3xl text-center mb-2">{tIcon[sel.type]}</div>
            <p className="font-bold text-gray-800 text-center mb-1">{sel.title}</p>
            <p className="text-2xl font-black text-blue-700 text-center mb-4">{fmt(sel.amount)}</p>
            <div className="bg-gray-50 rounded-xl p-3 mb-4 text-sm text-gray-600">{sel.description}</div>
            <div className="space-y-2 text-sm mb-4">
              {[["مقدّم من",sel.requestedBy],["نوع الطلب",sel.type],["التاريخ",fmtD(sel.date)],["الحالة",<SBadge status={sel.status}/>]].map(([k,v])=>(
                <div key={k} className="flex justify-between items-center"><span className="text-gray-500">{k}</span><span className="font-medium">{v}</span></div>
              ))}
            </div>
            {sel.status==="pending"&&<div className="flex gap-2"><Btn v="success" sz="sm" className="flex-1 justify-center" onClick={()=>{ approveReq(sel.id); setSel({...sel,status:"approved"}); }}>✅ موافقة</Btn><Btn v="danger" sz="sm" className="flex-1 justify-center" onClick={()=>{ rejectReq(sel.id); setSel({...sel,status:"rejected"}); }}>❌ رفض</Btn></div>}
          </Card>
        )}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════
//  NOTIFICATIONS
// ═══════════════════════════════════════════════════════
function Notifications() {
  const { notifs, markAllRead, markRead } = useApp();
  const ts = {warning:"bg-yellow-50 border-yellow-100",request:"bg-blue-50 border-blue-100",ai:"bg-purple-50 border-purple-100",success:"bg-green-50 border-green-100",info:"bg-gray-50 border-gray-100"};
  const dots = {warning:"bg-yellow-400",request:"bg-blue-500",ai:"bg-purple-500",success:"bg-green-500",info:"bg-gray-400"};
  return (
    <div className="space-y-5">
      <PageHeader title="الإشعارات والتنبيهات" subtitle={`${notifs.filter(n=>!n.read).length} إشعار غير مقروء`} actions={<Btn v="outline" sz="sm" onClick={markAllRead}>تحديد الكل كمقروء</Btn>}/>
      <Card className="p-5">
        <div className="space-y-3">
          {notifs.map(n=>(
            <div key={n.id} onClick={()=>markRead(n.id)} className={`flex items-start gap-4 p-4 rounded-xl border cursor-pointer transition-all ${ts[n.type]||ts.info} ${n.read?"opacity-60":""}`}>
              <div className="relative"><span className="text-2xl">{n.icon}</span>{!n.read&&<span className={`absolute -top-1 -left-1 w-3 h-3 rounded-full border-2 border-white ${dots[n.type]||dots.info}`}/>}</div>
              <div className="flex-1"><p className={`text-sm font-semibold ${n.read?"text-gray-600":"text-gray-900"}`}>{n.title}</p><p className="text-xs text-gray-500 mt-0.5">{n.message}</p><p className="text-xs text-gray-400 mt-1">{fmtD(n.date)}</p></div>
              {!n.read&&<span className="w-2 h-2 rounded-full bg-blue-500 flex-shrink-0 mt-2"/>}
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

// ═══════════════════════════════════════════════════════
//  PROJECTS PAGE
// ═══════════════════════════════════════════════════════
function Projects() {
  const { projects, setActivePid, activeProject } = useApp();
  return (
    <div className="space-y-5">
      <PageHeader title="المشاريع" subtitle="إدارة جميع مشاريعك" actions={<Btn sz="sm">+ مشروع جديد</Btn>}/>
      <div className="grid grid-cols-3 gap-4">
        {projects.map(p=>(
          <Card key={p.id} className="p-6" onClick={()=>setActivePid(p.id)}>
            <div className="flex items-start justify-between mb-4">
              <div className="w-12 h-12 rounded-2xl flex items-center justify-center text-2xl" style={{backgroundColor:p.color+"20"}}>{p.icon}</div>
              {activeProject?.id===p.id&&<span className="text-xs bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full font-medium">محدد</span>}
            </div>
            <h3 className="font-bold text-gray-900 mb-1">{p.name}</h3>
            <p className="text-xs text-gray-400 mb-4">{p.description}</p>
            <div className="border-t border-gray-100 pt-4 flex justify-between text-sm">
              <div><p className="text-xs text-gray-400">الرصيد</p><p className="font-bold text-gray-800">{p.balance.toLocaleString()} ر.س</p></div>
              <div className="text-left"><p className="text-xs text-gray-400">الأعضاء</p><p className="font-bold text-gray-800">{p.membersCount}</p></div>
            </div>
          </Card>
        ))}
        <div className="border-2 border-dashed border-gray-200 rounded-2xl p-6 flex flex-col items-center justify-center cursor-pointer hover:border-blue-300 hover:bg-blue-50/20 transition-all text-center min-h-48">
          <div className="w-12 h-12 rounded-2xl bg-gray-100 flex items-center justify-center text-2xl mb-3">+</div>
          <p className="font-medium text-gray-600">إضافة مشروع جديد</p>
          <p className="text-xs text-gray-400 mt-1">شركة، منزل، مطعم...</p>
        </div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════
//  SETTINGS
// ═══════════════════════════════════════════════════════
function Settings() {
  const { currentUser } = useApp();
  const sections = [
    { title:"الملف الشخصي", items:[{l:"الاسم",v:currentUser.name,t:"text"},{l:"البريد الإلكتروني",v:currentUser.email,t:"email"},{l:"رقم الجوال",v:"+966 50 123 4567",t:"text"}] },
    { title:"الإشعارات", items:[{l:"إشعارات البريد الإلكتروني",v:true,t:"toggle"},{l:"إشعارات الواتساب",v:false,t:"toggle"},{l:"إشعارات التطبيق",v:true,t:"toggle"}] },
    { title:"الأمان", items:[{l:"تغيير كلمة المرور",v:"••••••••",t:"password"},{l:"المصادقة الثنائية",v:false,t:"toggle"}] },
  ];
  return (
    <div className="space-y-5">
      <PageHeader title="الإعدادات" subtitle="إدارة حسابك وتفضيلاتك"/>
      <div className="max-w-2xl space-y-4">
        <Card className="p-6">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-blue-600 flex items-center justify-center text-white text-3xl font-bold">{currentUser.avatar}</div>
            <div><h3 className="font-bold text-gray-900 text-lg">{currentUser.name}</h3><p className="text-sm text-gray-500">{currentUser.email}</p><p className="text-xs text-blue-600 mt-1">{currentUser.role}</p></div>
            <Btn v="outline" sz="sm" className="mr-auto">تغيير الصورة</Btn>
          </div>
        </Card>
        {sections.map(section=>(
          <Card key={section.title} className="p-6">
            <h3 className="font-semibold text-gray-800 mb-4 pb-3 border-b border-gray-100">{section.title}</h3>
            <div className="space-y-4">
              {section.items.map(item=>(
                <div key={item.l} className="flex items-center justify-between">
                  <label className="text-sm text-gray-700">{item.l}</label>
                  {item.t==="toggle"
                    ? <div className={`w-11 h-6 rounded-full transition-colors cursor-pointer ${item.v?"bg-blue-600":"bg-gray-200"} relative`}><div className={`w-5 h-5 bg-white rounded-full absolute top-0.5 transition-all shadow-sm ${item.v?"left-5":"left-0.5"}`}/></div>
                    : <input type={item.t} defaultValue={item.v} className="border border-gray-200 rounded-lg px-3 py-1.5 text-sm text-gray-700 w-52 text-right focus:outline-none focus:ring-2 focus:ring-blue-500"/>}
                </div>
              ))}
            </div>
          </Card>
        ))}
        <Btn v="primary" sz="md">حفظ التغييرات</Btn>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════
//  AUTH PAGES
// ═══════════════════════════════════════════════════════
function Login({ onLogin }) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-950 to-blue-950 flex items-center justify-center p-4" dir="rtl">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="w-16 h-16 rounded-2xl bg-blue-600 flex items-center justify-center mx-auto mb-4"><span className="text-white font-black text-3xl" style={{fontFamily:"serif"}}>م</span></div>
          <h1 className="text-3xl font-black text-white">موازين</h1>
          <p className="text-blue-300 mt-2 text-sm">المنصة المالية الذكية</p>
        </div>
        <div className="bg-white rounded-3xl p-8 shadow-2xl">
          <h2 className="text-xl font-bold text-gray-900 mb-6 text-center">تسجيل الدخول</h2>
          <div className="space-y-4 mb-6">
            <div><label className="block text-sm font-medium text-gray-700 mb-1.5">البريد الإلكتروني</label><input defaultValue="mohammed@example.com" className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm text-right focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="البريد الإلكتروني"/></div>
            <div><label className="block text-sm font-medium text-gray-700 mb-1.5">كلمة المرور</label><input type="password" defaultValue="123456" className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm text-right focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="كلمة المرور"/></div>
          </div>
          <button onClick={onLogin} className="w-full bg-blue-600 text-white py-3 rounded-xl font-bold text-base hover:bg-blue-700 transition-colors shadow-lg shadow-blue-600/30">دخول إلى موازين</button>
          <p className="text-center text-sm text-gray-400 mt-4">ليس لديك حساب؟ <span className="text-blue-600 cursor-pointer font-medium">إنشاء حساب</span></p>
        </div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════
//  ROOT APP
// ═══════════════════════════════════════════════════════
const pageMap = {
  dashboard:     (onNav) => <Dashboard onNav={onNav}/>,
  projects:      ()      => <Projects/>,
  finance:       ()      => <Finance/>,
  documents:     (onNav) => <Documents onNav={onNav}/>,
  trackings:     ()      => <Trackings/>,
  requests:      ()      => <Requests/>,
  notifications: ()      => <Notifications/>,
  settings:      ()      => <Settings/>,
};

function AppShell() {
  const [page, setPage] = useState("dashboard");
  const renderPage = pageMap[page] || pageMap.dashboard;
  return (
    <div className="flex h-screen bg-gray-50 overflow-hidden" dir="rtl" style={{fontFamily:"'Segoe UI', Tahoma, Arial, sans-serif"}}>
      <Sidebar active={page} onNav={setPage}/>
      <main className="flex-1 overflow-y-auto p-6">{renderPage(setPage)}</main>
    </div>
  );
}

export default function App() {
  const [authed, setAuthed] = useState(false);
  if (!authed) return <Login onLogin={() => setAuthed(true)}/>;
  return <AppProvider><AppShell/></AppProvider>;
}
